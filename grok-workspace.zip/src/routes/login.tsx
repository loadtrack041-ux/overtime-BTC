import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { APP_NAME, DEVELOPER_NAME } from "@/lib/brand";
import { DEMO_PASSWORD } from "@/lib/overtime/demo";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user } = useCurrentUserState();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [showDemo, setShowDemo] = useState(false);

  if (user) return <Navigate to="/app" />;

  async function onEmailLogin(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    const { error } = await authClient.signIn.email({ email, password, callbackURL: "/app" });
    setBusy(false);
    if (error) {
      toast.error(error.message ?? "Could not sign in");
      return;
    }
    window.location.href = "/app";
  }

  async function onSignUp(event: FormEvent) {
    event.preventDefault();
    if (name.trim().length < 2) {
      toast.error("Enter your full name");
      return;
    }
    setBusy(true);
    const { error } = await authClient.signUp.email({
      name: name.trim(),
      email,
      password,
      callbackURL: "/app",
    });
    setBusy(false);
    if (error) {
      toast.error(error.message ?? "Could not create account");
      return;
    }
    window.location.href = "/app";
  }

  return (
    <main className="ledger-bg min-h-dvh px-4 py-10">
      <div className="mx-auto flex min-h-[80dvh] max-w-md flex-col justify-center">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">Supervisors & admins</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">{APP_NAME}</h1>
        <p className="mt-1 text-sm text-muted">Developed by {DEVELOPER_NAME}</p>
        <p className="mt-2 max-w-sm text-muted">
          Workers do not sign up here. They only open the personal link you send them.
        </p>

        <div className="mt-6 grid grid-cols-2 gap-1 rounded-lg bg-surface-2 p-1">
          <button
            type="button"
            onClick={() => setMode("signin")}
            className={cn("h-10 rounded-md text-sm font-medium", mode === "signin" ? "bg-surface text-ink shadow-soft" : "text-muted")}
          >
            Sign in
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={cn("h-10 rounded-md text-sm font-medium", mode === "signup" ? "bg-surface text-ink shadow-soft" : "text-muted")}
          >
            Supervisor sign up
          </button>
        </div>

        <form
          onSubmit={mode === "signin" ? onEmailLogin : onSignUp}
          className="mt-4 space-y-3 rounded-xl border border-line bg-surface p-5 shadow-soft"
        >
          {mode === "signup" ? (
            <Field label="Full name">
              <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
            </Field>
          ) : null}
          <Field label="Work email">
            <Input
              type="email"
              autoComplete="username"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
            />
          </Field>
          <Field label="Password">
            <Input
              type="password"
              autoComplete={mode === "signin" ? "current-password" : "new-password"}
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Field>
          <Button type="submit" size="xl" className="w-full" disabled={busy || !authEnabled}>
            {busy ? (mode === "signin" ? "Signing in…" : "Creating…") : mode === "signin" ? "Sign in" : "Create supervisor account"}
          </Button>
          {mode === "signin" ? (
            <a href="/forgot-password" className="block text-center text-sm text-muted underline-offset-4 hover:underline">
              Forgot password
            </a>
          ) : (
            <p className="text-xs text-muted">
              The first person to sign up becomes Super Admin. Later supervisor accounts wait for activation.
            </p>
          )}
        </form>

        {authEnabled ? (
          <div className="mt-4 space-y-2">
            <p className="text-center text-xs uppercase tracking-[0.16em] text-faint">or</p>
            {GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant="secondary"
                size="lg"
                className="w-full"
                onClick={() => signIn(p.providerId, { callbackURL: "/app" })}
              >
                Continue with {p.label}
              </Button>
            ))}
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">Sign-in is disabled.</p>
        )}

        <button
          type="button"
          className="mt-6 text-left text-sm text-muted underline-offset-4 hover:underline"
          onClick={() => setShowDemo((v) => !v)}
        >
          {showDemo ? "Hide demo accounts" : "Demo accounts"}
        </button>
        {showDemo ? (
          <div className="mt-2 rounded-lg border border-line bg-surface p-4 text-sm">
            <p className="text-muted">
              The first person to sign in becomes Super Admin and loads the sample company. Supervisors (password{" "}
              <span className="font-mono text-ink">{DEMO_PASSWORD}</span>):
            </p>
            <ul className="mt-2 space-y-1 font-mono text-xs">
              <li>Admin · maria.chen@northline.demo</li>
              <li>Supervisor · james.okonkwo@northline.demo</li>
            </ul>
            <p className="mt-2 text-muted">
              Demo workers have no password. After the sample company loads, open{" "}
              <span className="font-mono text-ink">/w/demo-luis</span> as a worker.
            </p>
          </div>
        ) : null}
        <p className="mt-8 text-center text-xs text-faint">Developed by {DEVELOPER_NAME}</p>
      </div>
    </main>
  );
}
