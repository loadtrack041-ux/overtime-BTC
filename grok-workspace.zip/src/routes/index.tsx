import { createFileRoute, getRouteApi, Link, Navigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { APP_NAME, DEVELOPER_NAME } from "@/lib/brand";

const rootRoute = getRouteApi("__root__");

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { sessionUser } = rootRoute.useRouteContext();
  const { user, isPending } = useCurrentUserState();
  if (user || sessionUser) return <Navigate to="/app" />;
  if (isPending) {
    return (
      <main className="ledger-bg grid min-h-dvh place-items-center px-6">
        <p className="font-display text-2xl font-semibold">{APP_NAME}</p>
      </main>
    );
  }

  return (
    <main className="ledger-bg min-h-dvh px-4 py-12">
      <div className="mx-auto max-w-lg">
        <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">Workforce hours</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">{APP_NAME}</h1>
        <p className="mt-1 text-sm text-muted">Developed by {DEVELOPER_NAME}</p>
        <p className="mt-3 max-w-md text-muted">
          Supervisors sign in. Workers never create an account — they open a private link, mark hazri, and log extra hours.
        </p>

        <div className="mt-8 space-y-3">
          <div className="rounded-xl border border-line bg-surface p-5 shadow-soft">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Supervisors</p>
            <p className="mt-1 font-display text-xl font-semibold">Sign in to approve</p>
            <p className="mt-1 text-sm text-muted">Add workers, share their links, then sign overtime on your phone.</p>
            <Link
              to="/login"
              className="mt-4 inline-flex h-12 w-full items-center justify-center rounded-md bg-accent text-accent-fg"
            >
              Supervisor sign in
            </Link>
          </div>
          <div className="rounded-xl border border-line bg-surface p-5 shadow-soft">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Workers</p>
            <p className="mt-1 font-display text-xl font-semibold">Use your personal link</p>
            <p className="mt-1 text-sm text-muted">
              No signup. Open the WhatsApp / SMS link from your supervisor. You only see your own attendance and overtime.
            </p>
          </div>
        </div>

        <p className="mt-10 text-center text-xs text-faint">Developed by {DEVELOPER_NAME}</p>
      </div>
    </main>
  );
}
