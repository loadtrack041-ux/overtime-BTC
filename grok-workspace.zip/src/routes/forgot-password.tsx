import { createFileRoute, Link } from "@tanstack/react-router";
import { APP_NAME } from "@/lib/brand";

export const Route = createFileRoute("/forgot-password")({ component: ForgotPassword });

function ForgotPassword() {
  return (
    <main className="ledger-bg grid min-h-dvh place-items-center px-4">
      <div className="w-full max-w-md rounded-xl border border-line bg-surface p-6 shadow-soft">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">Account recovery</p>
        <h1 className="mt-2 font-display text-2xl font-semibold">Reset happens through your admin</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          {APP_NAME} does not send reset emails. Ask your supervisor or an administrator to set a new
          password from People → the user → Reset password. That keeps payroll accounts inside the company.
        </p>
        <Link to="/login" className="mt-6 inline-flex h-12 items-center font-medium text-accent underline-offset-4 hover:underline">
          Back to sign in
        </Link>
      </div>
    </main>
  );
}
