import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { EmptyState, PageHeader } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { createDepartment, listDepartments, updateDepartment } from "@/lib/overtime/server-fns";
import { canManageUsers } from "@/lib/overtime/types";

export const Route = createFileRoute("/app/departments")({ component: DepartmentsPage });

function DepartmentsPage() {
  const actor = useActor();
  const qc = useQueryClient();
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const create = useMutation({
    mutationFn: () => createDepartment({ data: { name, code } }),
    onSuccess: async () => {
      toast.success("Department added");
      setName("");
      setCode("");
      await qc.invalidateQueries({ queryKey: ["departments"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <div>
      <PageHeader kicker="Organisation" title="Departments / projects" />
      {canManageUsers(actor.acting.role) ? (
        <form
          className="mb-5 grid gap-2 rounded-xl border border-line bg-surface p-4 md:grid-cols-[1fr_8rem_auto]"
          onSubmit={(e) => {
            e.preventDefault();
            create.mutate();
          }}
        >
          <Field label="Name">
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <Field label="Code">
            <Input value={code} onChange={(e) => setCode(e.target.value)} />
          </Field>
          <div className="flex items-end">
            <Button type="submit" className="w-full" disabled={create.isPending}>
              Add
            </Button>
          </div>
        </form>
      ) : null}
      <div className="space-y-2">
        {(depts.data ?? []).map((d) => (
          <div key={d.id} className="flex items-center justify-between rounded-xl border border-line bg-surface px-4 py-3">
            <div>
              <p className="font-medium">{d.name}</p>
              <p className="text-xs text-muted">{d.code ?? "No code"} · {d.isActive ? "Active" : "Inactive"}</p>
            </div>
            {canManageUsers(actor.acting.role) ? (
              <Button
                size="sm"
                variant="secondary"
                onClick={async () => {
                  await updateDepartment({ data: { id: d.id, isActive: !d.isActive } });
                  await qc.invalidateQueries({ queryKey: ["departments"] });
                }}
              >
                {d.isActive ? "Deactivate" : "Activate"}
              </Button>
            ) : null}
          </div>
        ))}
        {depts.data?.length === 0 ? <EmptyState title="No departments" body="Add warehouse, night shift, or project codes." /> : null}
      </div>
    </div>
  );
}
