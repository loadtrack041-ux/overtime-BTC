import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/records-page";

export const Route = createFileRoute("/app/records")({
  component: () => (
    <RecordsPage title="Overtime records" kicker="All statuses" hrefFor={(id) => `/app/overtime/${id}`} />
  ),
});
