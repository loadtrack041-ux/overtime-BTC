import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/app/supervisors")({
  component: () => <Navigate to="/app/people" />,
});
