import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/records-page";

export const Route = createFileRoute("/app/rejected")({
  component: () => (
    <RecordsPage
      title="Rejected overtime"
      kicker="Returned with a reason"
      status="rejected"
      hrefFor={(id) => `/app/overtime/${id}`}
    />
  ),
});
