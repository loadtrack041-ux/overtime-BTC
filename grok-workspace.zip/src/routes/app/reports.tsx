import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useActor } from "@/components/actor";
import { EmptyState, PageHeader, StatCard } from "@/components/empty-state";
import { OvertimeCard } from "@/components/overtime-card";
import { Field, Input, Select } from "@/components/ui/input";
import { currentMonthKey, formatHours } from "@/lib/overtime/hours";
import { listDepartments, listOvertime, listUsers } from "@/lib/overtime/server-fns";
import type { OtStatus } from "@/lib/overtime/types";
import { isAdminRole } from "@/lib/overtime/types";

export const Route = createFileRoute("/app/reports")({ component: ReportsPage });

const PRESETS: { id: string; label: string; status?: OtStatus }[] = [
  { id: "month", label: "Monthly" },
  { id: "approved", label: "Approved", status: "approved" },
  { id: "pending", label: "Pending", status: "pending" },
  { id: "rejected", label: "Rejected", status: "rejected" },
];

function ReportsPage() {
  const actor = useActor();
  const [preset, setPreset] = useState("month");
  const [month, setMonth] = useState(currentMonthKey());
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [workerUserId, setWorkerUserId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [supervisorUserId, setSupervisorUserId] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const status = PRESETS.find((p) => p.id === preset)?.status;

  const workers = useQuery({ queryKey: ["users", "worker"], queryFn: () => listUsers({ data: { role: "worker" } }) });
  const supervisors = useQuery({
    queryKey: ["users", "supervisor"],
    queryFn: () => listUsers({ data: { role: "supervisor" } }),
    enabled: isAdminRole(actor.acting.role),
  });
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const records = useQuery({
    queryKey: ["report", preset, month, from, to, workerUserId, employeeId, supervisorUserId, departmentId],
    queryFn: () =>
      listOvertime({
        data: {
          month: from || to ? undefined : month,
          from: from || undefined,
          to: to || undefined,
          workerUserId: workerUserId || undefined,
          employeeId: employeeId || undefined,
          supervisorUserId: supervisorUserId || undefined,
          departmentId: departmentId || undefined,
          status,
        },
      }),
  });

  const totals = useMemo(() => {
    const rows = records.data ?? [];
    const hours = rows.filter((r) => r.status !== "rejected").reduce((s, r) => s + r.totalHours, 0);
    return { count: rows.length, hours };
  }, [records.data]);

  return (
    <div>
      <PageHeader kicker="Analytics" title="Reports" />
      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => setPreset(p.id)}
            className={`h-10 shrink-0 rounded-full px-4 text-sm font-medium ${preset === p.id ? "bg-accent text-accent-fg" : "bg-surface-2 text-ink"}`}
          >
            {p.label}
          </button>
        ))}
      </div>
      <div className="grid gap-3 rounded-xl border border-line bg-surface p-4 md:grid-cols-3">
        <Field label="Month">
          <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
        </Field>
        <Field label="From">
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Field>
        <Field label="To">
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Field>
        <Field label="Worker">
          <Select value={workerUserId} onChange={(e) => setWorkerUserId(e.target.value)}>
            <option value="">All workers</option>
            {(workers.data ?? []).map((w) => (
              <option key={w.userId} value={w.userId}>
                {w.fullName}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Employee ID">
          <Input value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} placeholder="WH-3101" />
        </Field>
        {isAdminRole(actor.acting.role) ? (
          <Field label="Supervisor">
            <Select value={supervisorUserId} onChange={(e) => setSupervisorUserId(e.target.value)}>
              <option value="">All supervisors</option>
              {(supervisors.data ?? []).map((s) => (
                <option key={s.userId} value={s.userId}>
                  {s.fullName}
                </option>
              ))}
            </Select>
          </Field>
        ) : null}
        <Field label="Department / project">
          <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
            <option value="">All departments</option>
            {(depts.data ?? []).map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <StatCard label="Records" value={totals.count} />
        <StatCard label="Hours" value={formatHours(totals.hours)} />
      </div>

      <div className="mt-5 space-y-3">
        {(records.data ?? []).map((r) => (
          <OvertimeCard key={r.id} record={r} href={`/app/overtime/${r.id}`} />
        ))}
        {records.data?.length === 0 ? <EmptyState title="No matching overtime" body="Widen the filters or pick another month." /> : null}
      </div>

      {isAdminRole(actor.acting.role) ? (
        <p className="mt-6 text-sm text-muted">
          Need a spreadsheet? <Link to="/app/export" className="text-accent underline-offset-4 hover:underline">Export Excel</Link>
        </p>
      ) : null}
    </div>
  );
}
