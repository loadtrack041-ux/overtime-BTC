import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { PageHeader } from "@/components/empty-state";
import { SignaturePad } from "@/components/signature-pad";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Field, Textarea } from "@/components/ui/input";
import { formatClock, formatWorkDate } from "@/lib/overtime/format";
import { formatHours } from "@/lib/overtime/hours";
import { approveOvertime, getOvertime, rejectOvertime } from "@/lib/overtime/server-fns";

export const Route = createFileRoute("/app/approve/$id")({ component: ApprovePage });

function ApprovePage() {
  const { id } = Route.useParams();
  const actor = useActor();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const query = useQuery({ queryKey: ["ot", id], queryFn: () => getOvertime({ data: id }) });
  const rec = query.data;
  const [signature, setSignature] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [mode, setMode] = useState<"sign" | "reject">("sign");

  const approve = useMutation({
    mutationFn: () => approveOvertime({ data: { id, signatureData: signature ?? "" } }),
    onSuccess: async () => {
      toast.success("Overtime approved");
      await qc.invalidateQueries();
      void navigate({ to: "/app/pending" });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const reject = useMutation({
    mutationFn: () => rejectOvertime({ data: { id, reason } }),
    onSuccess: async () => {
      toast.success("Overtime rejected");
      await qc.invalidateQueries();
      void navigate({ to: "/app/pending" });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (query.isPending) return <div className="h-40 animate-pulse rounded-xl bg-surface-2" />;
  if (!rec) return <p className="text-sm text-muted">Record not found.</p>;
  if (actor.acting.role === "worker") {
    return <p className="text-sm text-muted">Workers cannot approve overtime.</p>;
  }
  if (rec.status !== "pending") {
    return (
      <div>
        <PageHeader title="Already reviewed" />
        <p className="text-sm text-muted">This overtime is {rec.status} and locked.</p>
      </div>
    );
  }

  return (
    <div>
      <PageHeader kicker="Digital signature" title={rec.workerName} action={<StatusBadge status={rec.status} />} />
      <div className="rounded-xl border border-line bg-surface p-4 shadow-soft">
        <p className="text-sm text-muted">{rec.employeeId} · {rec.departmentName}</p>
        <p className="mt-2 font-medium">{formatWorkDate(rec.workDate)}</p>
        <p className="text-sm">
          {formatClock(rec.startTime)} – {formatClock(rec.endTime)}
          {rec.crossesMidnight ? " · overnight" : ""}
        </p>
        <p className="mt-2 font-display text-3xl font-semibold tabular-nums">{formatHours(rec.totalHours)}</p>
        {rec.description ? <p className="mt-3 text-sm leading-relaxed text-muted">{rec.description}</p> : null}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button type="button" variant={mode === "sign" ? "primary" : "secondary"} onClick={() => setMode("sign")}>
          Approve & sign
        </Button>
        <Button type="button" variant={mode === "reject" ? "danger" : "secondary"} onClick={() => setMode("reject")}>
          Reject
        </Button>
      </div>

      {mode === "sign" ? (
        <div className="mt-4 space-y-3">
          <p className="text-sm font-medium">Supervisor signature</p>
          <SignaturePad value={signature} onChange={setSignature} />
          <Button
            type="button"
            size="xl"
            className="w-full"
            disabled={!signature || approve.isPending}
            onClick={() => approve.mutate()}
          >
            {approve.isPending ? "Saving…" : "Approve & lock"}
          </Button>
        </div>
      ) : (
        <div className="mt-4 space-y-3">
          <Field label="Rejection reason" hint="Required — the worker will see this">
            <Textarea value={reason} onChange={(e) => setReason(e.target.value)} required />
          </Field>
          <Button
            type="button"
            variant="danger"
            size="xl"
            className="w-full"
            disabled={reason.trim().length < 3 || reject.isPending}
            onClick={() => reject.mutate()}
          >
            {reject.isPending ? "Saving…" : "Reject overtime"}
          </Button>
        </div>
      )}
    </div>
  );
}
