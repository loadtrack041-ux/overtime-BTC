import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/records-page";

export const Route = createFileRoute("/app/my-overtime")({
  component: () => (
    <RecordsPage
      title="My overtime"
      kicker="Your hours"
      hrefFor={(id) => `/app/overtime/${id}`}
    />
  ),
});
