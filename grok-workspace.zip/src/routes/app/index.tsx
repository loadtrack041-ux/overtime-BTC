import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useActor } from "@/components/actor";
import { EmptyState, PageHeader, StatCard } from "@/components/empty-state";
import { MonthPicker } from "@/components/month-picker";
import { OvertimeCard } from "@/components/overtime-card";
import { RoleBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { currentMonthKey, formatHours } from "@/lib/overtime/hours";
import {
  dashboardStats,
  listOvertime,
  listUsers,
  startImpersonation,
  workerSummary,
} from "@/lib/overtime/server-fns";
import { isAdminRole } from "@/lib/overtime/types";
import { useState } from "react";
import { format, parseISO } from "date-fns";

export const Route = createFileRoute("/app/")({ component: Dashboard });

function Dashboard() {
  const actor = useActor();
  const [month, setMonth] = useState(currentMonthKey());
  const role = actor.acting.role;
  const stats = useQuery({ queryKey: ["stats", month], queryFn: () => dashboardStats({ data: month }) });
  const pending = useQuery({
    queryKey: ["ot", "pending", month],
    queryFn: () => listOvertime({ data: { month, status: "pending" } }),
  });
  const mine = useQuery({
    queryKey: ["ot", "mine", month],
    queryFn: () => listOvertime({ data: { month } }),
    enabled: role === "worker",
  });
  const summary = useQuery({
    queryKey: ["summary", month],
    queryFn: () => workerSummary({ data: { month } }),
    enabled: isAdminRole(role) || role === "supervisor",
  });
  const demoUsers = useQuery({
    queryKey: ["demo-users"],
    queryFn: () => listUsers({ data: {} }),
    enabled: actor.real.role === "super_admin" && !actor.impersonating,
  });

  const s = stats.data;
  const chart = (s?.daily ?? []).map((d) => ({
    label: format(parseISO(d.date), "d"),
    hours: d.hours,
  }));

  return (
    <div>
      <PageHeader
        kicker={actor.companyName}
        title={greeting(actor.acting.fullName)}
        action={<RoleBadge role={role} />}
      />
      <div className="mb-5">
        <MonthPicker value={month} onChange={setMonth} />
      </div>

      {role === "worker" ? (
        <Button asChild size="xl" className="mb-5 w-full">
          <Link to="/app/submit">Submit today’s overtime</Link>
        </Button>
      ) : (
        <p className="mb-5 rounded-lg border border-line bg-surface px-4 py-3 text-sm text-muted">
          Workers do not log in. Add them in People and send their personal link. They mark attendance and overtime; you sign to approve.
        </p>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {role !== "worker" ? <StatCard label="Workers" value={s?.totalWorkers ?? "—"} /> : null}
        <StatCard label="OT hours" value={s ? round(s.totalHours) : "—"} hint="Pending + approved" />
        <StatCard label="Pending" value={s?.pendingCount ?? "—"} hint={s ? formatHours(s.pendingHours) : undefined} />
        {role !== "worker" ? (
          <StatCard label="Hazri" value={s ? `${s.presentDays} in` : "—"} hint={s ? `${s.absentDays} absent` : undefined} />
        ) : (
          <StatCard label="Approved" value={s?.approvedCount ?? "—"} hint={s ? formatHours(s.approvedHours) : undefined} />
        )}
      </div>

      {chart.length > 0 ? (
        <div className="mt-5 rounded-xl border border-line bg-surface p-4 shadow-soft">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Daily hours</p>
          <div className="mt-2 h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} barCategoryGap={6}>
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#6b645b" }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip
                  cursor={{ fill: "rgba(33,86,76,0.08)" }}
                  contentStyle={{ borderRadius: 12, borderColor: "#ddd6c8", fontSize: 12 }}
                />
                <Bar dataKey="hours" fill="#21564c" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      ) : null}

      {actor.real.role === "super_admin" && !actor.impersonating ? (
        <DemoRoles users={demoUsers.data ?? []} />
      ) : null}

      {role === "worker" ? (
        <section className="mt-6">
          <h2 className="mb-3 font-display text-lg font-semibold">This month</h2>
          <div className="space-y-3">
            {(mine.data ?? []).slice(0, 6).map((r) => (
              <OvertimeCard key={r.id} record={r} href={`/app/overtime/${r.id}`} showWorker={false} />
            ))}
            {mine.data?.length === 0 ? (
              <EmptyState title="No overtime yet" body="Submit extra hours after your shift. Your supervisor will sign them on their phone." />
            ) : null}
          </div>
        </section>
      ) : (
        <section className="mt-6">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">Pending approvals</h2>
            <Link to="/app/pending" className="text-sm text-accent">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {(pending.data ?? []).slice(0, 5).map((r) => (
              <OvertimeCard key={r.id} record={r} href={`/app/approve/${r.id}`} />
            ))}
            {pending.data?.length === 0 ? (
              <EmptyState title="Nothing waiting" body="When your team submits overtime, it will land here for a signature." />
            ) : null}
          </div>
        </section>
      )}

      {(isAdminRole(role) || role === "supervisor") && summary.data ? (
        <section className="mt-8">
          <h2 className="mb-3 font-display text-lg font-semibold">Worker summary</h2>
          <div className="overflow-hidden rounded-xl border border-line bg-surface shadow-soft">
            <div className="hidden grid-cols-[1.4fr_1fr_1fr_1fr] gap-2 border-b border-line bg-surface-2 px-4 py-2 text-xs font-medium uppercase tracking-[0.12em] text-muted md:grid">
              <span>Worker</span>
              <span>Total OT</span>
              <span>Approved</span>
              <span>Pending</span>
            </div>
            {summary.data.map((w) => (
              <Link
                key={w.userId}
                to="/app/users/$id"
                params={{ id: w.userId }}
                className="grid grid-cols-2 gap-2 border-b border-line px-4 py-3 last:border-0 md:grid-cols-[1.4fr_1fr_1fr_1fr]"
              >
                <div>
                  <p className="font-medium">{w.fullName}</p>
                  <p className="text-xs text-muted">
                    {w.employeeId} · {w.departmentName ?? "No dept"}
                  </p>
                </div>
                <p className="tabular-nums text-sm">{round(w.totalHours)} h</p>
                <p className="tabular-nums text-sm text-approved">{round(w.approvedHours)} h</p>
                <p className="tabular-nums text-sm text-pending">{round(w.pendingHours)} h</p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function round(n: number) {
  return Math.round(n * 100) / 100;
}

function greeting(name: string) {
  const hour = new Date().getHours();
  const first = name.split(" ")[0] ?? name;
  if (hour < 12) return `Good morning, ${first}`;
  if (hour < 17) return `Good afternoon, ${first}`;
  return `Good evening, ${first}`;
}

function DemoRoles({
  users,
}: {
  users: { userId: string; fullName: string; role: string; email: string | null }[];
}) {
  const qc = useQueryClient();
  const picks = [
    users.find((u) => u.role === "admin"),
    users.find((u) => u.role === "supervisor"),
  ].filter(Boolean);

  if (picks.length === 0) return null;

  return (
    <section className="mt-6 rounded-xl border border-line bg-accent-soft/60 p-4">
      <p className="font-display text-lg font-semibold">Try a demo role</p>
      <p className="mt-1 text-sm text-muted">
        Walk as a supervisor or admin without signing out. Workers use a personal link, not this login.
      </p>
      <div className="mt-3 grid gap-2 md:grid-cols-3">
        {picks.map((u) =>
          u ? (
            <Button
              key={u.userId}
              type="button"
              variant="secondary"
              onClick={async () => {
                await startImpersonation({ data: u.userId });
                await qc.invalidateQueries();
                window.location.href = "/app";
              }}
            >
              {u.fullName.split(" ")[0]} · {u.role}
            </Button>
          ) : null,
        )}
        <Button type="button" variant="secondary" onClick={() => (window.location.href = "/w/demo-luis")}>
          Luis · worker link
        </Button>
      </div>
    </section>
  );
}
