import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { PageHeader } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { DEMO_PASSWORD } from "@/lib/overtime/demo";
import { getSettings, seedDemo, updateSettings } from "@/lib/overtime/server-fns";

export const Route = createFileRoute("/app/settings")({ component: SettingsPage });

function SettingsPage() {
  const actor = useActor();
  const qc = useQueryClient();
  const settings = useQuery({ queryKey: ["settings"], queryFn: () => getSettings() });
  const [companyName, setCompanyName] = useState("");
  const [timezone, setTimezone] = useState("Europe/Berlin");
  const [requireDescription, setRequireDescription] = useState(false);

  useEffect(() => {
    if (!settings.data) return;
    setCompanyName(settings.data.companyName);
    setTimezone(settings.data.timezone);
    setRequireDescription(settings.data.requireDescription);
  }, [settings.data]);

  const save = useMutation({
    mutationFn: () => updateSettings({ data: { companyName, timezone, requireDescription } }),
    onSuccess: async () => {
      toast.success("Settings saved");
      await qc.invalidateQueries({ queryKey: ["session"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (actor.acting.role !== "super_admin") {
    return <p className="text-sm text-muted">Only Super Admins can change system settings.</p>;
  }

  return (
    <div>
      <PageHeader kicker="System" title="Settings" />
      <form
        className="space-y-3 rounded-xl border border-line bg-surface p-4 shadow-soft"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <Field label="Company name">
          <Input value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
        </Field>
        <Field label="Timezone" hint="Stored for reports. Times are entered as local clock times.">
          <Input value={timezone} onChange={(e) => setTimezone(e.target.value)} />
        </Field>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={requireDescription}
            onChange={(e) => setRequireDescription(e.target.checked)}
          />
          Require a description on overtime submissions
        </label>
        <Button type="submit" disabled={save.isPending}>
          Save settings
        </Button>
      </form>

      <div className="mt-6 rounded-xl border border-line bg-surface p-4">
        <p className="font-display text-lg font-semibold">Sample company</p>
        <p className="mt-1 text-sm text-muted">
          Demo users share the password <span className="font-mono text-ink">{DEMO_PASSWORD}</span>. Seeding is
          safe to retry — existing demo IDs are left alone.
        </p>
        <Button
          className="mt-3"
          variant="secondary"
          onClick={async () => {
            await seedDemo();
            toast.success("Demo company ready");
            await qc.invalidateQueries();
          }}
        >
          Load sample company
        </Button>
      </div>
    </div>
  );
}
