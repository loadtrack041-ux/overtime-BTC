import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell, InactiveScreen, LoadingScreen } from "@/components/app-shell";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { loadSession } from "@/lib/overtime/server-fns";

export const Route = createFileRoute("/app")({ component: AppLayout });

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  const session = useQuery({
    queryKey: ["session"],
    queryFn: () => loadSession(),
    enabled: Boolean(user),
  });

  if (isPending) return <LoadingScreen />;
  if (!user) return <RedirectToSignIn />;
  if (session.isPending) return <LoadingScreen />;
  if (session.error || !session.data) {
    return (
      <div className="grid min-h-dvh place-items-center bg-paper px-6 text-center">
        <p className="text-sm text-muted">
          {session.error instanceof Error ? session.error.message : "Could not load your profile."}
        </p>
      </div>
    );
  }
  if (!session.data.acting.isActive) return <InactiveScreen actor={session.data} />;
  return <AppShell actor={session.data} />;
}
