import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { PageHeader } from "@/components/empty-state";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { formatClock, formatDateTime, formatWorkDate } from "@/lib/overtime/format";
import { formatHours } from "@/lib/overtime/hours";
import { getOvertime, withdrawOvertime } from "@/lib/overtime/server-fns";
import { isAdminRole } from "@/lib/overtime/types";

export const Route = createFileRoute("/app/overtime/$id")({ component: OvertimeDetail });

function OvertimeDetail() {
  const { id } = Route.useParams();
  const actor = useActor();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const query = useQuery({ queryKey: ["ot", id], queryFn: () => getOvertime({ data: id }) });
  const rec = query.data;

  const withdraw = useMutation({
    mutationFn: () => withdrawOvertime({ data: id }),
    onSuccess: async () => {
      toast.success("Overtime withdrawn");
      await qc.invalidateQueries();
      void navigate({ to: "/app/my-overtime" });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (query.isPending) return <div className="h-40 animate-pulse rounded-xl bg-surface-2" />;
  if (!rec) return <p className="text-sm text-muted">Record not found.</p>;

  const canEdit = actor.acting.role === "worker" && rec.status === "pending" && rec.workerUserId === actor.acting.userId;
  const canApprove =
    rec.status === "pending" &&
    rec.workerUserId !== actor.acting.userId &&
    (isAdminRole(actor.acting.role) || actor.acting.role === "supervisor");

  return (
    <div>
      <PageHeader kicker={rec.employeeId ?? "Overtime"} title={rec.workerName} action={<StatusBadge status={rec.status} />} />
      <div className="space-y-3">
        <div className="rounded-xl border border-line bg-surface p-4 shadow-soft">
          <Row label="Date" value={formatWorkDate(rec.workDate)} />
          <Row label="Start" value={formatClock(rec.startTime)} />
          <Row label="End" value={`${formatClock(rec.endTime)}${rec.crossesMidnight ? " (next day)" : ""}`} />
          <Row label="Total" value={formatHours(rec.totalHours)} />
          <Row label="Department" value={rec.departmentName ?? "—"} />
          <Row label="Supervisor" value={rec.supervisorName ?? "—"} />
        </div>
        {rec.description ? (
          <div className="rounded-xl border border-line bg-surface p-4">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Description</p>
            <p className="mt-2 text-sm leading-relaxed">{rec.description}</p>
          </div>
        ) : null}
        {rec.status === "approved" ? (
          <div className="rounded-xl border border-approved/20 bg-approved-bg p-4">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-approved">Signed approval</p>
            <p className="mt-1 text-sm">
              {rec.approvedByName} · {formatDateTime(rec.approvedAt)}
            </p>
            {rec.approvalIp ? <p className="text-xs text-muted">IP {rec.approvalIp}</p> : null}
            {rec.signatureData ? (
              <img src={rec.signatureData} alt="Supervisor signature" className="mt-3 w-full rounded-md bg-surface" />
            ) : null}
            <p className="mt-2 text-xs text-muted">This record is locked and cannot be edited.</p>
          </div>
        ) : null}
        {rec.status === "rejected" ? (
          <div className="rounded-xl border border-rejected/20 bg-rejected-bg p-4">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-rejected">Rejected</p>
            <p className="mt-1 text-sm">
              {rec.rejectedByName} · {formatDateTime(rec.rejectedAt)}
            </p>
            <p className="mt-2 text-sm leading-relaxed">{rec.rejectionReason}</p>
          </div>
        ) : null}
        {canEdit ? (
          <div className="grid grid-cols-2 gap-2">
            <Button asChild variant="secondary" size="lg">
              <Link to="/app/submit" search={{ edit: rec.id }}>
                Edit
              </Link>
            </Button>
            <Button variant="danger" size="lg" onClick={() => withdraw.mutate()} disabled={withdraw.isPending}>
              Withdraw
            </Button>
          </div>
        ) : null}
        {canApprove ? (
          <Button asChild size="xl" className="w-full">
            <Link to="/app/approve/$id" params={{ id: rec.id }}>
              Review & sign
            </Link>
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-line py-2 last:border-0">
      <span className="text-sm text-muted">{label}</span>
      <span className="text-sm font-medium tabular-nums">{value}</span>
    </div>
  );
}
