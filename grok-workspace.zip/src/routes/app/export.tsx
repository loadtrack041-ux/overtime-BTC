import { useMutation, useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { PageHeader } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { currentMonthKey } from "@/lib/overtime/hours";
import { exportExcel, listDepartments, listUsers } from "@/lib/overtime/server-fns";
import { canExport } from "@/lib/overtime/types";

export const Route = createFileRoute("/app/export")({ component: ExportPage });

function download(filename: string, xml: string) {
  const blob = new Blob([xml], { type: "application/vnd.ms-excel;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function ExportPage() {
  const actor = useActor();
  const [month, setMonth] = useState(currentMonthKey());
  const [departmentId, setDepartmentId] = useState("");
  const [supervisorUserId, setSupervisorUserId] = useState("");
  const [workerUserId, setWorkerUserId] = useState("");
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const supervisors = useQuery({
    queryKey: ["users", "supervisor"],
    queryFn: () => listUsers({ data: { role: "supervisor" } }),
  });
  const workers = useQuery({ queryKey: ["users", "worker"], queryFn: () => listUsers({ data: { role: "worker" } }) });

  const run = useMutation({
    mutationFn: () =>
      exportExcel({
        data: {
          month,
          departmentId: departmentId || undefined,
          supervisorUserId: supervisorUserId || undefined,
          workerUserId: workerUserId || undefined,
        },
      }),
    onSuccess: (file) => {
      download(file.filename, file.xml);
      toast.success("Excel report downloaded");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (!canExport(actor.acting.role)) {
    return <p className="text-sm text-muted">Only Admins and Super Admins can export company-wide Excel reports.</p>;
  }

  return (
    <div>
      <PageHeader kicker="Payroll" title="Export Excel" />
      <p className="mb-4 max-w-xl text-sm text-muted">
        One file for the whole team — daily lines, worker totals, and a grand total. Optional filters narrow the
        same workbook; leave them blank to include everyone.
      </p>
      <form
        className="space-y-3 rounded-xl border border-line bg-surface p-4 shadow-soft"
        onSubmit={(e) => {
          e.preventDefault();
          run.mutate();
        }}
      >
        <Field label="Month">
          <Input type="month" required value={month} onChange={(e) => setMonth(e.target.value)} />
        </Field>
        <Field label="Department / project">
          <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
            <option value="">All</option>
            {(depts.data ?? []).map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Supervisor">
          <Select value={supervisorUserId} onChange={(e) => setSupervisorUserId(e.target.value)}>
            <option value="">All</option>
            {(supervisors.data ?? []).map((s) => (
              <option key={s.userId} value={s.userId}>
                {s.fullName}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Worker">
          <Select value={workerUserId} onChange={(e) => setWorkerUserId(e.target.value)}>
            <option value="">All workers</option>
            {(workers.data ?? []).map((w) => (
              <option key={w.userId} value={w.userId}>
                {w.fullName}
              </option>
            ))}
          </Select>
        </Field>
        <Button type="submit" size="xl" className="w-full" disabled={run.isPending}>
          {run.isPending ? "Building workbook…" : "Export Excel"}
        </Button>
      </form>
    </div>
  );
}
