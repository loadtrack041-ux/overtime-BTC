import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/records-page";

export const Route = createFileRoute("/app/pending")({
  component: () => (
    <RecordsPage
      title="Pending approvals"
      kicker="Needs a signature"
      status="pending"
      hrefFor={(id) => `/app/approve/${id}`}
    />
  ),
});
