import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/records-page";

export const Route = createFileRoute("/app/approved")({
  component: () => (
    <RecordsPage
      title="Approved overtime"
      kicker="Signed and locked"
      status="approved"
      hrefFor={(id) => `/app/overtime/${id}`}
    />
  ),
});
