import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { authClient } from "@/lib/auth/client";

export const Route = createFileRoute("/app/change-password")({ component: ChangePassword });

function ChangePassword() {
  const [currentPassword, setCurrent] = useState("");
  const [newPassword, setNext] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <div>
      <PageHeader kicker="Account" title="Change password" />
      <form
        className="space-y-3 rounded-xl border border-line bg-surface p-4 shadow-soft"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          const { error } = await authClient.changePassword({ currentPassword, newPassword, revokeOtherSessions: true });
          setBusy(false);
          if (error) {
            toast.error(error.message ?? "Could not change password. Email/password accounts only.");
            return;
          }
          toast.success("Password updated");
          setCurrent("");
          setNext("");
        }}
      >
        <Field label="Current password">
          <Input type="password" required value={currentPassword} onChange={(e) => setCurrent(e.target.value)} />
        </Field>
        <Field label="New password" hint="At least 8 characters">
          <Input type="password" required minLength={8} value={newPassword} onChange={(e) => setNext(e.target.value)} />
        </Field>
        <Button type="submit" disabled={busy}>
          {busy ? "Saving…" : "Update password"}
        </Button>
      </form>
      <p className="mt-3 text-sm text-muted">
        Google or X sign-in does not use a local password. Ask an admin to attach one if you need email login.
      </p>
    </div>
  );
}
