import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/empty-state";
import { formatDateTime } from "@/lib/overtime/format";
import { listAudit } from "@/lib/overtime/server-fns";

export const Route = createFileRoute("/app/audit")({ component: AuditPage });

function AuditPage() {
  const logs = useQuery({ queryKey: ["audit"], queryFn: () => listAudit() });
  return (
    <div>
      <PageHeader kicker="Security" title="Audit log" />
      <div className="space-y-2">
        {(logs.data ?? []).map((row) => (
          <article key={row.id} className="rounded-xl border border-line bg-surface px-4 py-3">
            <div className="flex items-baseline justify-between gap-3">
              <p className="font-medium">{row.action}</p>
              <p className="text-xs tabular-nums text-muted">{formatDateTime(row.createdAt)}</p>
            </div>
            <p className="text-sm text-muted">
              {row.actorName ?? "System"} {row.actorRole ? `· ${row.actorRole}` : ""}
              {row.entityType ? ` · ${row.entityType}` : ""}
            </p>
            {row.details ? <p className="mt-1 break-all font-mono text-[11px] text-faint">{row.details}</p> : null}
          </article>
        ))}
      </div>
    </div>
  );
}
