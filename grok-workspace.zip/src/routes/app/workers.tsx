import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/app/workers")({
  component: () => <Navigate to="/app/people" />,
});
