import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { MonthPicker } from "@/components/month-picker";
import { OvertimeCard } from "@/components/overtime-card";
import { PageHeader } from "@/components/empty-state";
import { RoleBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { WorkerLinkCard } from "@/components/worker-link-card";
import { formatWorkDate } from "@/lib/overtime/format";
import { currentMonthKey } from "@/lib/overtime/hours";
import {
  getUser,
  getWorkerLink,
  listAttendance,
  listDepartments,
  listOvertime,
  listUsers,
  regenerateWorkerLink,
  resetUserPassword,
  startImpersonation,
  updateUser,
} from "@/lib/overtime/server-fns";
import type { Role } from "@/lib/overtime/types";
import { canAddWorkers, canManageAdmins, canManageUsers } from "@/lib/overtime/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/users/$id")({ component: UserDetail });

function UserDetail() {
  const { id } = Route.useParams();
  const actor = useActor();
  const qc = useQueryClient();
  const [month, setMonth] = useState(currentMonthKey());
  const user = useQuery({ queryKey: ["user", id], queryFn: () => getUser({ data: id }) });
  const records = useQuery({
    queryKey: ["ot", "worker", id, month],
    queryFn: () => listOvertime({ data: { month, workerUserId: id } }),
  });
  const attendance = useQuery({
    queryKey: ["att", "worker", id, month],
    queryFn: () => listAttendance({ data: { month, workerUserId: id } }),
    enabled: user.data?.role === "worker",
  });
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const supervisors = useQuery({
    queryKey: ["users", "supervisor"],
    queryFn: () => listUsers({ data: { role: "supervisor" } }),
  });
  const link = useQuery({
    queryKey: ["worker-link", id],
    queryFn: () => getWorkerLink({ data: id }),
    enabled: user.data?.role === "worker",
  });
  const profile = user.data;
  const [password, setPassword] = useState("");

  const save = useMutation({
    mutationFn: (patch: Parameters<typeof updateUser>[0]["data"]) => updateUser({ data: patch }),
    onSuccess: async () => {
      toast.success("Saved");
      await qc.invalidateQueries();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const reset = useMutation({
    mutationFn: () => resetUserPassword({ data: { userId: id, password } }),
    onSuccess: () => {
      toast.success("Password reset");
      setPassword("");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const rotate = useMutation({
    mutationFn: () => regenerateWorkerLink({ data: id }),
    onSuccess: async () => {
      toast.success("New link created. The old one no longer works.");
      await qc.invalidateQueries({ queryKey: ["worker-link", id] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (user.isPending) return <div className="h-40 animate-pulse rounded-xl bg-surface-2" />;
  if (!profile) return <p className="text-sm text-muted">User not found.</p>;

  const canEdit =
    (canManageUsers(actor.acting.role) && (profile.role !== "super_admin" || canManageAdmins(actor.acting.role))) ||
    (actor.acting.role === "supervisor" && profile.role === "worker" && profile.supervisorUserId === actor.acting.userId);
  const isWorker = profile.role === "worker";

  return (
    <div>
      <PageHeader kicker={profile.employeeId ?? "Profile"} title={profile.fullName} action={<RoleBadge role={profile.role} />} />
      <div className="rounded-xl border border-line bg-surface p-4 text-sm shadow-soft">
        <p>{profile.email ?? "No login account"}</p>
        <p className="text-muted">
          {profile.departmentName ?? "No department"} · Supervisor {profile.supervisorName ?? "—"}
        </p>
        <p className={profile.isActive ? "text-approved" : "text-rejected"}>{profile.isActive ? "Active" : "Deactivated"}</p>
      </div>

      {isWorker && link.data ? (
        <div className="mt-4">
          <WorkerLinkCard
            workerName={profile.fullName}
            path={link.data.path}
            onRotate={canAddWorkers(actor.acting.role) ? () => rotate.mutate() : undefined}
            rotating={rotate.isPending}
          />
        </div>
      ) : null}

      {actor.real.role === "super_admin" && profile.userId !== actor.real.userId && !isWorker ? (
        <Button
          className="mt-3 w-full"
          variant="secondary"
          onClick={async () => {
            await startImpersonation({ data: profile.userId });
            window.location.href = "/app";
          }}
        >
          View as {profile.fullName.split(" ")[0]}
        </Button>
      ) : null}

      {canEdit ? (
        <form
          className="mt-5 space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            const form = new FormData(e.currentTarget);
            save.mutate({
              userId: id,
              name: String(form.get("name") ?? profile.fullName),
              role: String(form.get("role") ?? profile.role) as Role,
              departmentId: String(form.get("departmentId") || "") || null,
              supervisorUserId: String(form.get("supervisorUserId") || "") || null,
              employeeId: String(form.get("employeeId") || "") || null,
            });
          }}
        >
          <Field label="Name">
            <Input name="name" defaultValue={profile.fullName} />
          </Field>
          <Field label="Employee ID">
            <Input name="employeeId" defaultValue={profile.employeeId ?? ""} />
          </Field>
          {canManageAdmins(actor.acting.role) ? (
            <Field label="Role">
              <Select name="role" defaultValue={profile.role}>
                <option value="worker">Worker</option>
                <option value="supervisor">Supervisor</option>
                <option value="admin">Admin</option>
                <option value="super_admin">Super Admin</option>
              </Select>
            </Field>
          ) : null}
          <Field label="Department">
            <Select name="departmentId" defaultValue={profile.departmentId ?? ""}>
              <option value="">None</option>
              {(depts.data ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          {isWorker && actor.acting.role !== "supervisor" ? (
            <Field label="Supervisor">
              <Select name="supervisorUserId" defaultValue={profile.supervisorUserId ?? ""}>
                <option value="">None</option>
                {(supervisors.data ?? []).map((s) => (
                  <option key={s.userId} value={s.userId}>
                    {s.fullName}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          <Button type="submit" disabled={save.isPending}>
            Save profile
          </Button>
          <Button
            type="button"
            variant={profile.isActive ? "danger" : "secondary"}
            onClick={() => save.mutate({ userId: id, isActive: !profile.isActive })}
          >
            {profile.isActive ? "Deactivate" : "Reactivate"}
          </Button>
          {!isWorker ? (
            <div className="rounded-lg border border-line p-3">
              <Field label="Reset password">
                <Input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="New password" />
              </Field>
              <Button type="button" className="mt-2" variant="secondary" disabled={password.length < 8} onClick={() => reset.mutate()}>
                Set password
              </Button>
            </div>
          ) : null}
        </form>
      ) : null}

      {isWorker ? (
        <div className="mt-8">
          <h2 className="mb-3 font-display text-lg font-semibold">Attendance</h2>
          <MonthPicker value={month} onChange={setMonth} />
          <div className="mt-3 space-y-2">
            {(attendance.data ?? []).map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-xl border border-line bg-surface px-4 py-3">
                <div>
                  <p className="font-medium">{formatWorkDate(a.workDate)}</p>
                  <p className="text-xs text-muted">
                    {a.clockIn && a.clockOut ? `${a.clockIn} – ${a.clockOut}` : "No clock times"}
                  </p>
                </div>
                <span className={cn("text-sm font-medium", a.status === "present" ? "text-approved" : "text-rejected")}>
                  {a.status === "present" ? "Present" : "Absent"}
                </span>
              </div>
            ))}
            {attendance.data?.length === 0 ? <p className="text-sm text-muted">No attendance this month.</p> : null}
          </div>
        </div>
      ) : null}

      <div className="mt-8">
        <h2 className="mb-3 font-display text-lg font-semibold">Overtime history</h2>
        {!isWorker ? <MonthPicker value={month} onChange={setMonth} /> : null}
        <div className="mt-3 space-y-3">
          {(records.data ?? []).map((r) => (
            <OvertimeCard
              key={r.id}
              record={r}
              href={r.status === "pending" ? `/app/approve/${r.id}` : `/app/overtime/${r.id}`}
              showWorker={false}
            />
          ))}
          {records.data?.length === 0 ? <p className="text-sm text-muted">No overtime this month.</p> : null}
        </div>
      </div>
    </div>
  );
}
