import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { EmptyState, PageHeader } from "@/components/empty-state";
import { RoleBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { WorkerLinkCard } from "@/components/worker-link-card";
import { createUser, createWorker, listDepartments, listUsers } from "@/lib/overtime/server-fns";
import type { Role } from "@/lib/overtime/types";
import { canAddWorkers, canManageAdmins, canManageUsers } from "@/lib/overtime/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/app/people")({ component: PeoplePage });

const TABS: { id: Role; label: string }[] = [
  { id: "worker", label: "Workers" },
  { id: "supervisor", label: "Supervisors" },
  { id: "admin", label: "Admins" },
];

function PeoplePage() {
  const actor = useActor();
  const [tab, setTab] = useState<Role>("worker");
  const [creating, setCreating] = useState(false);
  const [createdLink, setCreatedLink] = useState<{ name: string; path: string } | null>(null);
  const users = useQuery({ queryKey: ["users", tab], queryFn: () => listUsers({ data: { role: tab } }) });
  const canCreateStaff = canManageUsers(actor.acting.role) && (tab !== "admin" || canManageAdmins(actor.acting.role));
  const canCreate =
    tab === "worker" ? canAddWorkers(actor.acting.role) : canCreateStaff;

  return (
    <div>
      <PageHeader
        kicker="Directory"
        title="People"
        action={
          canCreate ? (
            <Button size="sm" onClick={() => setCreating(true)}>
              Add {tab}
            </Button>
          ) : null
        }
      />
      {tab === "worker" ? (
        <p className="mb-4 rounded-lg border border-line bg-surface px-4 py-3 text-sm text-muted">
          Workers never sign up. Add them here and send their personal link. They only mark attendance and overtime.
        </p>
      ) : null}
      {actor.acting.role !== "supervisor" ? (
        <div className="mb-4 grid grid-cols-3 gap-1 rounded-lg bg-surface-2 p-1">
          {TABS.filter((t) => t.id !== "admin" || canManageUsers(actor.acting.role)).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                "h-10 rounded-md text-sm font-medium",
                tab === t.id ? "bg-surface text-ink shadow-soft" : "text-muted",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      ) : null}
      <div className="space-y-2">
        {(users.data ?? []).map((u) => (
          <Link
            key={u.userId}
            to="/app/users/$id"
            params={{ id: u.userId }}
            className="flex items-center justify-between rounded-xl border border-line bg-surface px-4 py-3 shadow-soft"
          >
            <div>
              <p className="font-medium">{u.fullName}</p>
              <p className="text-xs text-muted">
                {u.employeeId ?? "No ID"} · {u.departmentName ?? "No dept"} {u.isActive ? "" : "· Deactivated"}
              </p>
            </div>
            <RoleBadge role={u.role} />
          </Link>
        ))}
        {users.data?.length === 0 ? (
          <EmptyState
            title="No people here"
            body={tab === "worker" ? "Add a worker and share their link. They will not need an account." : "Create supervisors so they can approve overtime."}
          />
        ) : null}
      </div>
      {creating && tab === "worker" ? (
        <CreateWorkerDialog
          onClose={() => setCreating(false)}
          onCreated={(info) => {
            setCreating(false);
            setCreatedLink(info);
          }}
        />
      ) : null}
      {creating && tab !== "worker" ? <CreateStaffDialog role={tab} onClose={() => setCreating(false)} /> : null}
      {createdLink ? (
        <div className="fixed inset-0 z-50 grid place-items-end md:place-items-center">
          <button type="button" className="absolute inset-0 bg-ink/40" aria-label="Close" onClick={() => setCreatedLink(null)} />
          <div className="relative z-10 w-full rounded-t-xl border border-line bg-surface p-5 shadow-soft md:max-w-md md:rounded-xl">
            <h2 className="font-display text-xl font-semibold">Share this link</h2>
            <div className="mt-4">
              <WorkerLinkCard workerName={createdLink.name} path={createdLink.path} />
            </div>
            <Button className="mt-4 w-full" variant="secondary" onClick={() => setCreatedLink(null)}>
              Done
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function CreateWorkerDialog({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (info: { name: string; path: string }) => void;
}) {
  const actor = useActor();
  const qc = useQueryClient();
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const supervisors = useQuery({
    queryKey: ["users", "supervisor"],
    queryFn: () => listUsers({ data: { role: "supervisor" } }),
    enabled: actor.acting.role !== "supervisor",
  });
  const [name, setName] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [supervisorUserId, setSupervisorUserId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [phone, setPhone] = useState("");

  const mutation = useMutation({
    mutationFn: () =>
      createWorker({
        data: {
          name,
          departmentId: departmentId || null,
          supervisorUserId: supervisorUserId || null,
          employeeId: employeeId || null,
          phone: phone || null,
        },
      }),
    onSuccess: async (result) => {
      toast.success("Worker added");
      await qc.invalidateQueries({ queryKey: ["users"] });
      if (result?.profile && result.path) {
        onCreated({ name: result.profile.fullName, path: result.path });
      } else {
        onClose();
      }
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <div className="fixed inset-0 z-50 grid place-items-end md:place-items-center">
      <button type="button" className="absolute inset-0 bg-ink/40" aria-label="Close" onClick={onClose} />
      <form
        className="relative z-10 max-h-[90dvh] w-full overflow-y-auto rounded-t-xl border border-line bg-surface p-5 shadow-soft md:max-w-md md:rounded-xl"
        onSubmit={(e) => {
          e.preventDefault();
          mutation.mutate();
        }}
      >
        <h2 className="font-display text-xl font-semibold">New worker</h2>
        <p className="mt-1 text-sm text-muted">No email or password. They open a private link on their phone.</p>
        <div className="mt-4 space-y-3">
          <Field label="Full name">
            <Input required value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Phone" hint="Optional">
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <Field label="Employee ID" hint="Leave blank to auto-assign">
            <Input value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} />
          </Field>
          <Field label="Department / project">
            <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
              <option value="">None</option>
              {(depts.data ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          {actor.acting.role !== "supervisor" ? (
            <Field label="Supervisor">
              <Select required value={supervisorUserId} onChange={(e) => setSupervisorUserId(e.target.value)}>
                <option value="">Select supervisor</option>
                {(supervisors.data ?? []).map((s) => (
                  <option key={s.userId} value={s.userId}>
                    {s.fullName}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
          <Button type="submit" size="lg" className="w-full" disabled={mutation.isPending}>
            {mutation.isPending ? "Creating…" : "Create worker link"}
          </Button>
        </div>
      </form>
    </div>
  );
}

function CreateStaffDialog({ role, onClose }: { role: Role; onClose: () => void }) {
  const qc = useQueryClient();
  const depts = useQuery({ queryKey: ["departments"], queryFn: () => listDepartments() });
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("Ledger2026!");
  const [departmentId, setDepartmentId] = useState("");
  const [employeeId, setEmployeeId] = useState("");

  const mutation = useMutation({
    mutationFn: () =>
      createUser({
        data: {
          name,
          email,
          password,
          role,
          departmentId: departmentId || null,
          employeeId: employeeId || null,
        },
      }),
    onSuccess: async () => {
      toast.success("Account created");
      await qc.invalidateQueries({ queryKey: ["users"] });
      onClose();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <div className="fixed inset-0 z-50 grid place-items-end md:place-items-center">
      <button type="button" className="absolute inset-0 bg-ink/40" aria-label="Close" onClick={onClose} />
      <form
        className="relative z-10 max-h-[90dvh] w-full overflow-y-auto rounded-t-xl border border-line bg-surface p-5 shadow-soft md:max-w-md md:rounded-xl"
        onSubmit={(e) => {
          e.preventDefault();
          mutation.mutate();
        }}
      >
        <h2 className="font-display text-xl font-semibold">New {role.replace("_", " ")}</h2>
        <div className="mt-4 space-y-3">
          <Field label="Full name">
            <Input required value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Email">
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Temporary password">
            <Input value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <Field label="Employee ID" hint="Leave blank to auto-assign">
            <Input value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} />
          </Field>
          <Field label="Department / project">
            <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
              <option value="">None</option>
              {(depts.data ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" size="lg" className="w-full" disabled={mutation.isPending}>
            {mutation.isPending ? "Creating…" : "Create account"}
          </Button>
        </div>
      </form>
    </div>
  );
}
