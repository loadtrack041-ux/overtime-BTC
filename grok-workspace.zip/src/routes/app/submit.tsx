import { useMutation, useQuery } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useActor } from "@/components/actor";
import { PageHeader } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { calculateOvertimeHours, formatHours, isValidTime } from "@/lib/overtime/hours";
import { getOvertime, submitOvertime } from "@/lib/overtime/server-fns";

type Search = { edit?: string };

export const Route = createFileRoute("/app/submit")({
  component: SubmitPage,
  validateSearch: (search: Record<string, unknown>): Search => ({
    edit: typeof search.edit === "string" ? search.edit : undefined,
  }),
});

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function SubmitPage() {
  const actor = useActor();
  const navigate = useNavigate();
  const { edit } = Route.useSearch();
  const existing = useQuery({
    queryKey: ["ot", edit],
    queryFn: () => getOvertime({ data: edit! }),
    enabled: Boolean(edit),
  });

  const [date, setDate] = useState(todayISO());
  const [startTime, setStartTime] = useState("17:00");
  const [endTime, setEndTime] = useState("20:00");
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (!existing.data) return;
    setDate(existing.data.workDate);
    setStartTime(existing.data.startTime);
    setEndTime(existing.data.endTime);
    setDescription(existing.data.description ?? "");
  }, [existing.data]);

  const calc = useMemo(() => {
    if (!isValidTime(startTime) || !isValidTime(endTime)) return null;
    try {
      return calculateOvertimeHours(startTime, endTime);
    } catch {
      return null;
    }
  }, [startTime, endTime]);

  const mutation = useMutation({
    mutationFn: () =>
      submitOvertime({
        data: { id: edit, date, startTime, endTime, description },
      }),
    onSuccess: () => {
      toast.success(edit ? "Overtime updated" : "Overtime submitted");
      void navigate({ to: "/app/my-overtime" });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (actor.acting.role !== "worker") {
    return <p className="text-sm text-muted">Only workers submit overtime from this screen.</p>;
  }

  return (
    <div>
      <PageHeader kicker="Daily overtime" title={edit ? "Edit overtime" : "Submit overtime"} />
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          mutation.mutate();
        }}
      >
        <div className="rounded-xl border border-line bg-surface p-4 shadow-soft">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Worker</p>
          <p className="mt-1 text-lg font-medium">{actor.acting.fullName}</p>
          <p className="text-sm text-muted">
            {actor.acting.employeeId ?? "No ID"} · {actor.acting.departmentName ?? "No department"}
          </p>
          <p className="text-sm text-muted">Supervisor {actor.acting.supervisorName ?? "unassigned"}</p>
        </div>

        <Field label="Date">
          <Input type="date" required value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Start time">
            <Input type="time" required value={startTime} onChange={(e) => setStartTime(e.target.value)} />
          </Field>
          <Field label="End time">
            <Input type="time" required value={endTime} onChange={(e) => setEndTime(e.target.value)} />
          </Field>
        </div>

        <div className="rounded-xl border border-accent/20 bg-accent-soft px-4 py-4">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-accent">Total overtime</p>
          <p className="mt-1 font-display text-3xl font-semibold tabular-nums">
            {calc ? formatHours(calc.hours) : "—"}
          </p>
          {calc?.crossesMidnight ? <p className="mt-1 text-sm text-pending">This shift crosses midnight</p> : null}
        </div>

        <Field label="Description / reason" hint="Optional — what you stayed for">
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Late vessel, machine repair, covering an absent teammate…"
          />
        </Field>

        <Button type="submit" size="xl" className="w-full" disabled={!calc || mutation.isPending}>
          {mutation.isPending ? "Saving…" : edit ? "Save changes" : "Submit overtime"}
        </Button>
      </form>
    </div>
  );
}
