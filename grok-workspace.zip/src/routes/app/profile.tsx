import { createFileRoute, Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { useActor } from "@/components/actor";
import { PageHeader } from "@/components/empty-state";
import { RoleBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/app/profile")({ component: ProfilePage });

function ProfilePage() {
  const { acting, real, impersonating, companyName } = useActor();
  return (
    <div>
      <PageHeader kicker={companyName} title="Profile" action={<RoleBadge role={acting.role} />} />
      <div className="rounded-xl border border-line bg-surface p-4 shadow-soft">
        <p className="text-xl font-medium">{acting.fullName}</p>
        <p className="text-sm text-muted">{acting.email}</p>
        <dl className="mt-4 space-y-2 text-sm">
          <Row label="Employee ID" value={acting.employeeId ?? "—"} />
          <Row label="Department" value={acting.departmentName ?? "—"} />
          <Row label="Supervisor" value={acting.supervisorName ?? "—"} />
          <Row label="Status" value={acting.isActive ? "Active" : "Deactivated"} />
        </dl>
      </div>
      {impersonating ? (
        <p className="mt-3 text-sm text-pending">You are viewing this profile through Super Admin preview.</p>
      ) : (
        <p className="mt-3 text-sm text-muted">Signed in as {real.fullName}.</p>
      )}
      <div className="mt-5 flex flex-col gap-2">
        <Button asChild variant="secondary">
          <Link to="/app/change-password">Change password</Link>
        </Button>
        <div className="rounded-xl border border-line bg-surface px-4 py-3">
          <UserButton />
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3 border-b border-line py-2 last:border-0">
      <dt className="text-muted">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  );
}
