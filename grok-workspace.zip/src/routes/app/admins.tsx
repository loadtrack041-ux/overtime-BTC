import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/app/admins")({
  component: () => <Navigate to="/app/people" />,
});
