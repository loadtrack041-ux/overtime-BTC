import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { OvertimeCard } from "@/components/overtime-card";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { formatWorkDate } from "@/lib/overtime/format";
import { calculateOvertimeHours, currentMonthKey, formatHours, isValidTime } from "@/lib/overtime/hours";
import {
  listWorkerAttendance,
  listWorkerOvertime,
  loadWorkerPortal,
  markWorkerAttendance,
  submitWorkerOvertime,
  withdrawWorkerOvertime,
} from "@/lib/overtime/worker-fns";
import type { AttendanceStatus } from "@/lib/overtime/types";
import { APP_NAME, DEVELOPER_NAME } from "@/lib/brand";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/w/$token")({ component: WorkerPortalPage });

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function WorkerPortalPage() {
  const { token } = Route.useParams();
  const portal = useQuery({
    queryKey: ["worker-portal", token],
    queryFn: () => loadWorkerPortal({ data: token }),
    retry: false,
  });

  if (portal.isPending) {
    return (
      <main className="ledger-bg grid min-h-dvh place-items-center px-6">
        <p className="font-display text-2xl font-semibold">Opening your shift book</p>
      </main>
    );
  }

  if (portal.error || !portal.data) {
    return (
      <main className="ledger-bg grid min-h-dvh place-items-center px-6">
        <div className="max-w-sm rounded-xl border border-line bg-surface p-6 text-center shadow-soft">
          <p className="font-display text-2xl font-semibold">Link not valid</p>
          <p className="mt-2 text-sm text-muted">
            {portal.error instanceof Error
              ? portal.error.message
              : "Ask your supervisor to send a new personal link. You do not need to sign up."}
          </p>
        </div>
      </main>
    );
  }

  return <WorkerDesk token={token} companyName={portal.data.companyName} workerName={portal.data.worker.fullName} employeeId={portal.data.worker.employeeId} supervisorName={portal.data.worker.supervisorName} departmentName={portal.data.worker.departmentName} />;
}

function WorkerDesk({
  token,
  companyName,
  workerName,
  employeeId,
  supervisorName,
  departmentName,
}: {
  token: string;
  companyName: string;
  workerName: string;
  employeeId: string | null;
  supervisorName: string | null;
  departmentName: string | null;
}) {
  const qc = useQueryClient();
  const month = currentMonthKey();
  const today = todayISO();
  const [date, setDate] = useState(today);
  const [attStatus, setAttStatus] = useState<AttendanceStatus>("present");
  const [clockIn, setClockIn] = useState("08:00");
  const [clockOut, setClockOut] = useState("17:00");
  const [startTime, setStartTime] = useState("17:00");
  const [endTime, setEndTime] = useState("20:00");
  const [description, setDescription] = useState("");
  const [tab, setTab] = useState<"today" | "history">("today");

  const attendance = useQuery({
    queryKey: ["w-att", token, month],
    queryFn: () => listWorkerAttendance({ data: { token, month } }),
  });
  const overtime = useQuery({
    queryKey: ["w-ot", token, month],
    queryFn: () => listWorkerOvertime({ data: { token, month } }),
  });

  const todayAtt = (attendance.data ?? []).find((a) => a.workDate === date);

  const calc = useMemo(() => {
    if (!isValidTime(startTime) || !isValidTime(endTime)) return null;
    try {
      return calculateOvertimeHours(startTime, endTime);
    } catch {
      return null;
    }
  }, [startTime, endTime]);

  const saveAttendance = useMutation({
    mutationFn: () =>
      markWorkerAttendance({
        data: {
          token,
          date,
          status: attStatus,
          clockIn: attStatus === "present" ? clockIn : undefined,
          clockOut: attStatus === "present" ? clockOut : undefined,
        },
      }),
    onSuccess: async () => {
      toast.success(attStatus === "present" ? "Hazri saved — present" : "Marked absent");
      await qc.invalidateQueries({ queryKey: ["w-att", token] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const saveOt = useMutation({
    mutationFn: () =>
      submitWorkerOvertime({
        data: { token, date, startTime, endTime, description },
      }),
    onSuccess: async () => {
      toast.success("Overtime sent to your supervisor");
      setDescription("");
      await qc.invalidateQueries({ queryKey: ["w-ot", token] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const withdraw = useMutation({
    mutationFn: (id: string) => withdrawWorkerOvertime({ data: { token, id } }),
    onSuccess: async () => {
      toast.success("Overtime withdrawn");
      await qc.invalidateQueries({ queryKey: ["w-ot", token] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <main className="min-h-dvh bg-paper text-ink">
      <header className="border-b border-line bg-surface/95 px-4 py-4 backdrop-blur">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">{APP_NAME}</p>
        <p className="mt-1 text-[11px] text-faint">{companyName}</p>
        <h1 className="mt-1 font-display text-2xl font-semibold tracking-tight">{workerName}</h1>
        <p className="text-sm text-muted">
          {employeeId ?? "No ID"} · {departmentName ?? "No department"}
        </p>
        <p className="text-sm text-muted">Supervisor {supervisorName ?? "—"}</p>
      </header>

      <div className="mx-auto max-w-lg px-4 py-5 pb-24">
        <div className="mb-5 grid grid-cols-2 gap-1 rounded-lg bg-surface-2 p-1">
          <button
            type="button"
            onClick={() => setTab("today")}
            className={cn("h-11 rounded-md text-sm font-medium", tab === "today" ? "bg-surface text-ink shadow-soft" : "text-muted")}
          >
            Today
          </button>
          <button
            type="button"
            onClick={() => setTab("history")}
            className={cn("h-11 rounded-md text-sm font-medium", tab === "history" ? "bg-surface text-ink shadow-soft" : "text-muted")}
          >
            My hours
          </button>
        </div>

        {tab === "today" ? (
          <div className="space-y-6">
            <section className="rounded-xl border border-line bg-surface p-4 shadow-soft">
              <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Hazri · Attendance</p>
              <p className="mt-1 font-display text-xl font-semibold">{formatWorkDate(date)}</p>
              <Field label="Date" hint="Aaj ya pichle din ki hazri">
                <Input type="date" value={date} max={today} onChange={(e) => setDate(e.target.value)} />
              </Field>
              {todayAtt ? (
                <p className="mt-2 text-sm text-approved">
                  Already marked {todayAtt.status}
                  {todayAtt.clockIn ? ` · ${todayAtt.clockIn}–${todayAtt.clockOut ?? "…"}` : ""}
                </p>
              ) : null}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Button type="button" variant={attStatus === "present" ? "primary" : "secondary"} onClick={() => setAttStatus("present")}>
                  Present
                </Button>
                <Button type="button" variant={attStatus === "absent" ? "danger" : "secondary"} onClick={() => setAttStatus("absent")}>
                  Absent
                </Button>
              </div>
              {attStatus === "present" ? (
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <Field label="Clock in">
                    <Input type="time" value={clockIn} onChange={(e) => setClockIn(e.target.value)} />
                  </Field>
                  <Field label="Clock out">
                    <Input type="time" value={clockOut} onChange={(e) => setClockOut(e.target.value)} />
                  </Field>
                </div>
              ) : (
                <p className="mt-3 text-sm text-muted">Supervisor will see you were off this day.</p>
              )}
              <Button
                type="button"
                size="lg"
                className="mt-4 w-full"
                disabled={saveAttendance.isPending}
                onClick={() => saveAttendance.mutate()}
              >
                {saveAttendance.isPending ? "Saving…" : "Save attendance"}
              </Button>
            </section>

            <section className="rounded-xl border border-line bg-surface p-4 shadow-soft">
              <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Overtime ghante</p>
              <h2 className="mt-1 font-display text-xl font-semibold">Extra hours</h2>
              <p className="mt-1 text-sm text-muted">Supervisor sign karke approve karega. Pura project yahan nahi dikhega.</p>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <Field label="Start">
                  <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
                </Field>
                <Field label="End">
                  <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
                </Field>
              </div>
              <div className="mt-3 rounded-lg bg-accent-soft px-4 py-3">
                <p className="text-xs font-medium uppercase tracking-[0.14em] text-accent">Total overtime</p>
                <p className="font-display text-3xl font-semibold tabular-nums">{calc ? formatHours(calc.hours) : "—"}</p>
                {calc?.crossesMidnight ? <p className="text-sm text-pending">Overnight shift</p> : null}
              </div>
              <Field label="Reason" hint="Optional — kyun ruke">
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Late truck, covering a teammate…" />
              </Field>
              <Button
                type="button"
                size="xl"
                className="mt-4 w-full"
                disabled={!calc || saveOt.isPending}
                onClick={() => saveOt.mutate()}
              >
                {saveOt.isPending ? "Sending…" : "Submit overtime"}
              </Button>
            </section>
          </div>
        ) : (
          <div className="space-y-6">
            <section>
              <h2 className="mb-3 font-display text-lg font-semibold">Attendance this month</h2>
              <div className="space-y-2">
                {(attendance.data ?? []).map((a) => (
                  <div key={a.id} className="flex items-center justify-between rounded-xl border border-line bg-surface px-4 py-3">
                    <div>
                      <p className="font-medium">{formatWorkDate(a.workDate)}</p>
                      <p className="text-xs text-muted">
                        {a.clockIn && a.clockOut ? `${a.clockIn} – ${a.clockOut}` : "No clock times"}
                      </p>
                    </div>
                    <span className={cn("text-sm font-medium", a.status === "present" ? "text-approved" : "text-rejected")}>
                      {a.status === "present" ? "Present" : "Absent"}
                    </span>
                  </div>
                ))}
                {attendance.data?.length === 0 ? (
                  <p className="text-sm text-muted">No attendance marked yet.</p>
                ) : null}
              </div>
            </section>
            <section>
              <h2 className="mb-3 font-display text-lg font-semibold">Overtime this month</h2>
              <div className="space-y-3">
                {(overtime.data ?? []).map((r) => (
                  <OvertimeCard
                    key={r.id}
                    record={r}
                    showWorker={false}
                    footer={
                      r.status === "pending" ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="mt-2"
                          disabled={withdraw.isPending}
                          onClick={() => withdraw.mutate(r.id)}
                        >
                          Withdraw
                        </Button>
                      ) : null
                    }
                  />
                ))}
                {overtime.data?.length === 0 ? (
                  <p className="text-sm text-muted">No overtime submitted this month.</p>
                ) : null}
              </div>
            </section>
          </div>
        )}

        <p className="mt-8 text-center text-xs text-faint">
          Bookmark this page. Supervisors sign in separately.{" "}
          <Link to="/login" className="underline-offset-2 hover:underline">
            Supervisor sign in
          </Link>
        </p>
        <p className="mt-3 text-center text-[11px] text-faint">
          {APP_NAME} · Developed by {DEVELOPER_NAME}
        </p>
      </div>
    </main>
  );
}
