import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  ClipboardCheck,
  Clock3,
  FileSpreadsheet,
  LayoutDashboard,
  MoreHorizontal,
  Plus,
  ScrollText,
  Users,
} from "lucide-react";
import { useState } from "react";
import { UserButton } from "@/lib/auth/gates";
import { APP_NAME, DEVELOPER_NAME } from "@/lib/brand";
import { stopImpersonation } from "@/lib/overtime/server-fns";
import type { Actor, Role } from "@/lib/overtime/types";
import { isAdminRole } from "@/lib/overtime/types";
import { cn } from "@/lib/utils";
import { ActorProvider, useActor } from "./actor";
import { initials } from "@/lib/overtime/format";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard; roles: Role[] };

const PRIMARY: NavItem[] = [
  { to: "/app", label: "Home", icon: LayoutDashboard, roles: ["super_admin", "admin", "supervisor", "worker"] },
  { to: "/app/submit", label: "Submit", icon: Plus, roles: ["worker"] },
  { to: "/app/pending", label: "Pending", icon: ClipboardCheck, roles: ["supervisor", "admin", "super_admin"] },
  { to: "/app/my-overtime", label: "My OT", icon: Clock3, roles: ["worker"] },
  { to: "/app/records", label: "Records", icon: ScrollText, roles: ["supervisor", "admin", "super_admin"] },
  { to: "/app/people", label: "People", icon: Users, roles: ["admin", "super_admin", "supervisor"] },
  { to: "/app/export", label: "Export", icon: FileSpreadsheet, roles: ["admin", "super_admin"] },
];

const MORE: { to: string; label: string; roles: Role[] }[] = [
  { to: "/app/approved", label: "Approved", roles: ["supervisor", "admin", "super_admin"] },
  { to: "/app/rejected", label: "Rejected", roles: ["supervisor", "admin", "super_admin"] },
  { to: "/app/reports", label: "Reports", roles: ["admin", "super_admin", "supervisor"] },
  { to: "/app/departments", label: "Departments", roles: ["admin", "super_admin"] },
  { to: "/app/audit", label: "Audit log", roles: ["admin", "super_admin"] },
  { to: "/app/settings", label: "Settings", roles: ["super_admin"] },
  { to: "/app/profile", label: "Profile", roles: ["super_admin", "admin", "supervisor", "worker"] },
];

function visible<T extends { roles: Role[] }>(items: T[], role: Role): T[] {
  return items.filter((i) => i.roles.includes(role));
}

export function AppShell({ actor }: { actor: Actor }) {
  return (
    <ActorProvider actor={actor}>
      <ShellFrame />
    </ActorProvider>
  );
}

function ShellFrame() {
  const actor = useActor();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [moreOpen, setMoreOpen] = useState(false);
  const role = actor.acting.role;
  const tabs = visible(PRIMARY, role).slice(0, 4);
  const moreItems: { to: string; label: string }[] = [
    ...visible(PRIMARY, role).slice(4),
    ...visible(MORE, role),
  ];

  return (
    <div className="min-h-dvh bg-paper text-ink">
      {actor.impersonating ? (
        <div className="flex items-center justify-between gap-3 bg-pending px-4 py-2 text-sm text-accent-fg">
          <p>
            Viewing as <span className="font-semibold">{actor.acting.fullName}</span> · {actor.acting.role.replace("_", " ")}
          </p>
          <button
            type="button"
            className="underline underline-offset-2"
            onClick={() => {
              void stopImpersonation().then(() => window.location.reload());
            }}
          >
            Exit
          </button>
        </div>
      ) : null}
      <header className="sticky top-0 z-20 hidden border-b border-line bg-surface/90 backdrop-blur md:block">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link to="/app" className="flex items-baseline gap-2">
            <span className="font-display text-lg font-semibold tracking-tight">{actor.companyName}</span>
            <span className="text-xs uppercase tracking-[0.14em] text-muted">{APP_NAME}</span>
          </Link>
          <nav className="flex items-center gap-1">
            {visible(PRIMARY, role).map((item) => (
              <NavLink key={item.to} to={item.to} active={isActive(pathname, item.to)}>
                {item.label}
              </NavLink>
            ))}
            {visible(MORE, role)
              .filter((i) => i.to !== "/app/profile")
              .map((item) => (
                <NavLink key={item.to} to={item.to} active={isActive(pathname, item.to)}>
                  {item.label}
                </NavLink>
              ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/app/profile" className="text-sm text-muted hover:text-ink">
              {actor.acting.fullName}
            </Link>
            <UserButton />
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-5 md:px-6 md:pb-12 md:pt-8">
        <Outlet />
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
        <div className="grid grid-cols-5">
          {tabs.map((item) => {
            const Icon = item.icon;
            const active = isActive(pathname, item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
                  active ? "text-accent" : "text-muted",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.4 : 1.8} />
                {item.label}
              </Link>
            );
          })}
          <button
            type="button"
            onClick={() => setMoreOpen((v) => !v)}
            className={cn(
              "flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium",
              moreOpen ? "text-accent" : "text-muted",
            )}
          >
            <MoreHorizontal className="size-5" />
            More
          </button>
        </div>
      </nav>

      {moreOpen ? (
        <div className="fixed inset-0 z-40 md:hidden">
          <button type="button" className="absolute inset-0 bg-ink/30" aria-label="Close menu" onClick={() => setMoreOpen(false)} />
          <div className="absolute inset-x-0 bottom-0 rounded-t-xl border border-line bg-surface p-4 pb-[calc(env(safe-area-inset-bottom)+1rem)] shadow-soft">
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line-strong" />
            <div className="mb-3 flex items-center gap-3">
              <div className="grid size-10 place-items-center rounded-full bg-accent-soft text-sm font-semibold text-accent">
                {initials(actor.acting.fullName)}
              </div>
              <div>
                <p className="font-medium">{actor.acting.fullName}</p>
                <p className="text-xs text-muted">{actor.acting.employeeId ?? actor.acting.email}</p>
              </div>
            </div>
            <div className="grid gap-1">
              {moreItems.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMoreOpen(false)}
                  className="rounded-md px-3 py-3 text-sm hover:bg-surface-2"
                >
                  {item.label}
                </Link>
              ))}
            </div>
            <p className="mt-4 text-center text-[11px] text-faint">
              {APP_NAME} · Developed by {DEVELOPER_NAME}
            </p>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function isActive(pathname: string, to: string) {
  if (to === "/app") return pathname === "/app" || pathname === "/app/";
  return pathname === to || pathname.startsWith(`${to}/`);
}

function NavLink({ to, active, children }: { to: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className={cn(
        "rounded-md px-3 py-2 text-sm font-medium",
        active ? "bg-accent-soft text-accent" : "text-muted hover:bg-surface-2 hover:text-ink",
      )}
    >
      {children}
    </Link>
  );
}

export function InactiveScreen({ actor }: { actor: Actor }) {
  return (
    <div className="ledger-bg grid min-h-dvh place-items-center px-6">
      <div className="max-w-md rounded-xl border border-line bg-surface p-6 text-center shadow-soft">
        <p className="font-display text-2xl font-semibold">Account pending</p>
        <p className="mt-2 text-sm text-muted">
          {actor.acting.fullName}, your supervisor account is waiting for an administrator to activate it.
          Workers never sign up — they use a personal link after you are approved.
        </p>
        <div className="mt-5">
          <UserButton />
        </div>
      </div>
    </div>
  );
}

export function LoadingScreen() {
  return (
    <div className="ledger-bg grid min-h-dvh place-items-center px-6">
      <div className="text-center">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">{APP_NAME}</p>
        <p className="mt-2 font-display text-2xl font-semibold">Loading your shift book</p>
        <p className="mt-2 text-xs text-faint">Developed by {DEVELOPER_NAME}</p>
      </div>
    </div>
  );
}
