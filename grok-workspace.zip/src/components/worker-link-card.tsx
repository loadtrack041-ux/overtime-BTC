import { Check, Copy, RefreshCw } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export function workerLinkUrl(path: string): string {
  if (typeof window === "undefined") return path;
  return `${window.location.origin}${path}`;
}

export async function copyText(value: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    return false;
  }
}

export function WorkerLinkCard({
  workerName,
  path,
  onRotate,
  rotating,
}: {
  workerName: string;
  path: string;
  onRotate?: () => void;
  rotating?: boolean;
}) {
  const url = workerLinkUrl(path);
  const [copied, setCopied] = useState(false);

  return (
    <div className="rounded-xl border border-accent/20 bg-accent-soft/70 p-4">
      <p className="text-xs font-medium uppercase tracking-[0.14em] text-accent">Personal worker link</p>
      <p className="mt-1 text-sm text-muted">
        {workerName} does not sign up. Send this private link on WhatsApp. They only see their own hazri and overtime.
      </p>
      <p className="mt-3 break-all rounded-md bg-surface px-3 py-2 font-mono text-xs text-ink">{url}</p>
      <div className="mt-3 flex flex-col gap-2 sm:flex-row">
        <Button
          type="button"
          className="flex-1"
          onClick={async () => {
            const ok = await copyText(url);
            if (ok) {
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1600);
            }
          }}
        >
          {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
          {copied ? "Copied" : "Copy link"}
        </Button>
        {onRotate ? (
          <Button type="button" variant="secondary" onClick={onRotate} disabled={rotating}>
            <RefreshCw className="size-4" />
            {rotating ? "Replacing…" : "New link"}
          </Button>
        ) : null}
      </div>
      {onRotate ? (
        <p className="mt-2 text-xs text-muted">A new link disables the old one. Share the new URL after rotating.</p>
      ) : null}
    </div>
  );
}
