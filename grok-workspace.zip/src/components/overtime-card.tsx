import { Link } from "@tanstack/react-router";
import { Clock3, Moon } from "lucide-react";
import type { ReactNode } from "react";
import { StatusBadge } from "@/components/status-badge";
import { formatClock, formatWorkDate } from "@/lib/overtime/format";
import { formatHours } from "@/lib/overtime/hours";
import type { OvertimeRecord } from "@/lib/overtime/types";
import { cn } from "@/lib/utils";

export function OvertimeCard({
  record,
  href,
  showWorker = true,
  footer,
}: {
  record: OvertimeRecord;
  href?: string;
  showWorker?: boolean;
  footer?: ReactNode;
}) {
  const body = (
    <>
      <div className="flex items-start justify-between gap-3">
        <div>
          {showWorker ? <p className="font-medium">{record.workerName}</p> : null}
          <p className="text-sm text-muted">{formatWorkDate(record.workDate)}</p>
        </div>
        <StatusBadge status={record.status} />
      </div>
      <div className="mt-3 flex items-center gap-3 text-sm">
        <span className="inline-flex items-center gap-1.5 text-ink">
          <Clock3 className="size-4 text-muted" />
          {formatClock(record.startTime)} – {formatClock(record.endTime)}
        </span>
        {record.crossesMidnight ? (
          <span className="inline-flex items-center gap-1 text-pending">
            <Moon className="size-3.5" />
            Overnight
          </span>
        ) : null}
      </div>
      <p className="mt-2 font-display text-xl font-semibold tabular-nums">{formatHours(record.totalHours)}</p>
      {record.description ? <p className="mt-1 line-clamp-2 text-sm text-muted">{record.description}</p> : null}
      {record.rejectionReason ? (
        <p className="mt-2 text-sm text-rejected">{record.rejectionReason}</p>
      ) : null}
      {footer}
    </>
  );

  const className = cn(
    "block rounded-xl border border-line bg-surface p-4 shadow-soft",
    href && "transition-transform duration-150 active:scale-[0.99]",
  );

  if (href) {
    return (
      <Link to={href} className={className}>
        {body}
      </Link>
    );
  }
  return <div className={className}>{body}</div>;
}
