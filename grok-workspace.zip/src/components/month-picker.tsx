import { ChevronLeft, ChevronRight } from "lucide-react";
import { monthBounds, shiftMonth } from "@/lib/overtime/hours";
import { Button } from "@/components/ui/button";

export function MonthPicker({ value, onChange }: { value: string; onChange: (next: string) => void }) {
  const { label } = monthBounds(value);
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-line bg-surface px-2 py-1.5">
      <Button type="button" variant="ghost" size="icon" aria-label="Previous month" onClick={() => onChange(shiftMonth(value, -1))}>
        <ChevronLeft className="size-5" />
      </Button>
      <p className="font-display text-base font-semibold tabular-nums">{label}</p>
      <Button type="button" variant="ghost" size="icon" aria-label="Next month" onClick={() => onChange(shiftMonth(value, 1))}>
        <ChevronRight className="size-5" />
      </Button>
    </div>
  );
}
