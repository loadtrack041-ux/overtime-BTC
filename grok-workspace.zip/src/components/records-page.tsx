import { useQuery } from "@tanstack/react-query";
import { EmptyState, PageHeader } from "@/components/empty-state";
import { MonthPicker } from "@/components/month-picker";
import { OvertimeCard } from "@/components/overtime-card";
import { currentMonthKey } from "@/lib/overtime/hours";
import { listOvertime } from "@/lib/overtime/server-fns";
import type { OtStatus } from "@/lib/overtime/types";
import { useState } from "react";
import { useActor } from "./actor";

export function RecordsPage({
  title,
  kicker,
  status,
  hrefFor,
}: {
  title: string;
  kicker: string;
  status?: OtStatus;
  hrefFor: (id: string) => string;
}) {
  const actor = useActor();
  const [month, setMonth] = useState(currentMonthKey());
  const query = useQuery({
    queryKey: ["ot", status ?? "all", month, actor.acting.userId],
    queryFn: () => listOvertime({ data: { month, status } }),
  });

  return (
    <div>
      <PageHeader kicker={kicker} title={title} />
      <div className="mb-4">
        <MonthPicker value={month} onChange={setMonth} />
      </div>
      <div className="space-y-3">
        {(query.data ?? []).map((r) => (
          <OvertimeCard
            key={r.id}
            record={r}
            href={hrefFor(r.id)}
            showWorker={actor.acting.role !== "worker"}
          />
        ))}
        {query.data?.length === 0 ? (
          <EmptyState title="No records" body="Nothing in this month matches the current filter." />
        ) : null}
      </div>
    </div>
  );
}
