import { cn } from "@/lib/utils";
import type { OtStatus, Role } from "@/lib/overtime/types";
import { ROLE_LABEL, STATUS_LABEL } from "@/lib/overtime/types";

export function StatusBadge({ status }: { status: OtStatus }) {
  const cls =
    status === "approved"
      ? "bg-approved-bg text-approved"
      : status === "rejected"
        ? "bg-rejected-bg text-rejected"
        : "bg-pending-bg text-pending";
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold", cls)}>
      {STATUS_LABEL[status]}
    </span>
  );
}

export function RoleBadge({ role }: { role: Role }) {
  return (
    <span className="inline-flex items-center rounded-full bg-accent-soft px-2.5 py-1 text-xs font-semibold text-accent">
      {ROLE_LABEL[role]}
    </span>
  );
}
