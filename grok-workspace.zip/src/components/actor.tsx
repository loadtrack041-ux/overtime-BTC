import { createContext, useContext, type ReactNode } from "react";
import type { Actor } from "@/lib/overtime/types";

const ActorContext = createContext<Actor | null>(null);

export function ActorProvider({ actor, children }: { actor: Actor; children: ReactNode }) {
  return <ActorContext.Provider value={actor}>{children}</ActorContext.Provider>;
}

export function useActor(): Actor {
  const value = useContext(ActorContext);
  if (!value) throw new Error("useActor must be used within the app shell");
  return value;
}
