import { getSql } from "@/lib/db";
import { hashPassword } from "better-auth/crypto";
import { DEMO_PASSWORD } from "./demo";
import { calculateOvertimeHours } from "./hours";
import type { Profile } from "./types";

export { DEMO_PASSWORD };

function sig(name: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="420" height="130" viewBox="0 0 420 130"><path d="M18 86 C 70 18, 110 110, 168 52 S 250 18, 310 78 S 360 96, 402 42" fill="none" stroke="#1a1714" stroke-width="3.2" stroke-linecap="round"/><text x="22" y="118" font-family="Georgia, serif" font-size="13" fill="#6b645b">${name}</text></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

type DemoUser = {
  id: string;
  name: string;
  email: string | null;
  role: "admin" | "supervisor" | "worker";
  employeeId: string;
  departmentId: string | null;
  supervisorId: string | null;
  token?: string;
};

const DEPTS = [
  { id: "dept-warehouse", name: "Warehouse", code: "WH" },
  { id: "dept-dispatch", name: "Dispatch", code: "DS" },
  { id: "dept-night", name: "Night Shift", code: "NS" },
  { id: "dept-maintenance", name: "Maintenance", code: "MT" },
];

const USERS: DemoUser[] = [
  {
    id: "demo-admin",
    name: "Maria Chen",
    email: "maria.chen@northline.demo",
    role: "admin",
    employeeId: "AD-1001",
    departmentId: null,
    supervisorId: null,
  },
  {
    id: "demo-supervisor-1",
    name: "James Okonkwo",
    email: "james.okonkwo@northline.demo",
    role: "supervisor",
    employeeId: "SV-2001",
    departmentId: "dept-warehouse",
    supervisorId: null,
  },
  {
    id: "demo-supervisor-2",
    name: "Priya Raman",
    email: "priya.raman@northline.demo",
    role: "supervisor",
    employeeId: "SV-2002",
    departmentId: "dept-night",
    supervisorId: null,
  },
  {
    id: "demo-worker-1",
    name: "Luis Ferreira",
    email: null,
    role: "worker",
    employeeId: "WH-3101",
    departmentId: "dept-warehouse",
    supervisorId: "demo-supervisor-1",
    token: "demo-luis",
  },
  {
    id: "demo-worker-2",
    name: "Kenji Watanabe",
    email: null,
    role: "worker",
    employeeId: "WH-3102",
    departmentId: "dept-warehouse",
    supervisorId: "demo-supervisor-1",
    token: "demo-kenji",
  },
  {
    id: "demo-worker-3",
    name: "Amina Diallo",
    email: null,
    role: "worker",
    employeeId: "WH-3103",
    departmentId: "dept-warehouse",
    supervisorId: "demo-supervisor-1",
    token: "demo-amina",
  },
  {
    id: "demo-worker-4",
    name: "Elena Rossi",
    email: null,
    role: "worker",
    employeeId: "NS-4101",
    departmentId: "dept-night",
    supervisorId: "demo-supervisor-2",
    token: "demo-elena",
  },
  {
    id: "demo-worker-5",
    name: "Omar Haddad",
    email: null,
    role: "worker",
    employeeId: "NS-4102",
    departmentId: "dept-night",
    supervisorId: "demo-supervisor-2",
    token: "demo-omar",
  },
  {
    id: "demo-worker-6",
    name: "Grace Nkomo",
    email: null,
    role: "worker",
    employeeId: "MT-5101",
    departmentId: "dept-maintenance",
    supervisorId: "demo-supervisor-1",
    token: "demo-grace",
  },
];

type OtSeed = {
  id: string;
  worker: string;
  date: string;
  start: string;
  end: string;
  description: string;
  status: "pending" | "approved" | "rejected";
  reason?: string;
};

const RECORDS: OtSeed[] = [
  { id: "ot-1", worker: "demo-worker-1", date: "2026-09-22", start: "17:00", end: "20:00", description: "Container unload after late vessel", status: "approved" },
  { id: "ot-2", worker: "demo-worker-1", date: "2026-09-28", start: "17:30", end: "21:00", description: "Inventory recount", status: "approved" },
  { id: "ot-3", worker: "demo-worker-1", date: "2026-10-01", start: "17:00", end: "20:00", description: "Covered outbound dock", status: "pending" },
  { id: "ot-4", worker: "demo-worker-2", date: "2026-09-18", start: "16:00", end: "19:30", description: "Forklift coverage", status: "approved" },
  { id: "ot-5", worker: "demo-worker-2", date: "2026-09-29", start: "17:00", end: "22:00", description: "Weekend inbound", status: "rejected", reason: "Weekend inbound was already staffed. Please confirm with dispatch before submitting." },
  { id: "ot-6", worker: "demo-worker-2", date: "2026-10-01", start: "17:00", end: "19:00", description: "Aisle 12 restock", status: "pending" },
  { id: "ot-7", worker: "demo-worker-3", date: "2026-09-24", start: "17:00", end: "20:30", description: "Returns processing", status: "approved" },
  { id: "ot-8", worker: "demo-worker-3", date: "2026-09-30", start: "17:00", end: "21:00", description: "Month-end cycle count", status: "approved" },
  { id: "ot-9", worker: "demo-worker-4", date: "2026-09-21", start: "23:00", end: "02:30", description: "Line 3 breakdown — stayed to clear backlog", status: "approved" },
  { id: "ot-10", worker: "demo-worker-4", date: "2026-09-27", start: "22:00", end: "01:00", description: "Covered absent picker", status: "approved" },
  { id: "ot-11", worker: "demo-worker-4", date: "2026-09-30", start: "22:30", end: "01:30", description: "Night inbound from Rotterdam", status: "pending" },
  { id: "ot-12", worker: "demo-worker-5", date: "2026-09-19", start: "22:00", end: "01:45", description: "Reefer container check", status: "approved" },
  { id: "ot-13", worker: "demo-worker-5", date: "2026-09-26", start: "23:00", end: "03:00", description: "Double shift request", status: "rejected", reason: "Consecutive long nights exceed the rest-period policy." },
  { id: "ot-14", worker: "demo-worker-5", date: "2026-10-01", start: "22:00", end: "00:30", description: "Late truck arrival", status: "pending" },
  { id: "ot-15", worker: "demo-worker-6", date: "2026-09-20", start: "16:00", end: "19:00", description: "Conveyor belt repair", status: "approved" },
  { id: "ot-16", worker: "demo-worker-6", date: "2026-09-25", start: "18:00", end: "21:30", description: "Dock door 4 hydraulics", status: "approved" },
  { id: "ot-17", worker: "demo-worker-6", date: "2026-09-30", start: "17:00", end: "20:00", description: "Preventative maintenance catch-up", status: "pending" },
  { id: "ot-18", worker: "demo-worker-3", date: "2026-09-16", start: "17:00", end: "18:30", description: "Label reprint run", status: "approved" },
];

export const DEMO_ACCOUNTS = USERS.filter((u) => u.email).map((u) => ({
  role: u.role,
  name: u.name,
  email: u.email!,
  password: DEMO_PASSWORD,
}));

export const DEMO_WORKER_LINKS = USERS.filter((u) => u.token).map((u) => ({
  name: u.name,
  employeeId: u.employeeId,
  token: u.token!,
}));

export async function seedDemoCompany(actor: Profile): Promise<void> {
  const sql = await getSql();
  const exists = await sql.query<{ user_id: string }>(
    `select user_id from profiles where user_id = 'demo-admin'`,
  );
  if (exists[0]) return;

  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const now = new Date().toISOString();

  await sql.query(
    `insert into system_settings (key, value) values ('company_name', 'Northline Logistics')
     on conflict (key) do update set value = excluded.value`,
  );

  for (const d of DEPTS) {
    await sql.query(
      `insert into departments (id, name, code, is_active) values ($1,$2,$3,true)
       on conflict (id) do nothing`,
      [d.id, d.name, d.code],
    );
  }

  for (const u of USERS) {
    if (u.role !== "worker" && u.email) {
      await sql.query(
        `insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
         values ($1,$2,$3,true,$4,$4) on conflict (id) do nothing`,
        [u.id, u.name, u.email, now],
      );
      await sql.query(
        `insert into "account" (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
         values ($1,$2,'credential',$3,$4,$5,$5) on conflict (id) do nothing`,
        [`acc-${u.id}`, u.id, u.id, passwordHash, now],
      );
    }
    await sql.query(
      `insert into profiles (user_id, role, full_name, employee_id, department_id, supervisor_user_id, is_active, created_by)
       values ($1,$2,$3,$4,$5,$6,true,$7) on conflict (user_id) do nothing`,
      [u.id, u.role, u.name, u.employeeId, u.departmentId, u.supervisorId, actor.userId],
    );
    if (u.role === "worker" && u.token) {
      await sql.query(
        `insert into worker_links (token, worker_user_id) values ($1,$2) on conflict (token) do nothing`,
        [u.token, u.id],
      );
    }
  }

  for (const rec of RECORDS) {
    const worker = USERS.find((u) => u.id === rec.worker)!;
    const { hours, crossesMidnight } = calculateOvertimeHours(rec.start, rec.end);
    const supervisor = worker.supervisorId;
    const supervisorName = USERS.find((u) => u.id === supervisor)?.name ?? null;
    const approved = rec.status === "approved";
    const rejected = rec.status === "rejected";
    const stamp = `${rec.date}T20:14:00.000Z`;
    await sql.query(
      `insert into overtime_records (
        id, worker_user_id, work_date, start_time, end_time, total_hours, crosses_midnight,
        description, status, department_id, supervisor_user_id,
        approved_by_user_id, approved_by_name, signature_data, approved_at, approval_ip, approval_user_agent,
        rejection_reason, rejected_at, rejected_by_user_id, rejected_by_name
      ) values (
        $1,$2,$3,$4,$5,$6,$7,
        $8,$9,$10,$11,
        $12,$13,$14,$15,$16,$17,
        $18,$19,$20,$21
      ) on conflict (id) do nothing`,
      [
        rec.id,
        rec.worker,
        rec.date,
        rec.start,
        rec.end,
        hours,
        crossesMidnight,
        rec.description,
        rec.status,
        worker.departmentId,
        supervisor,
        approved ? supervisor : null,
        approved ? supervisorName : null,
        approved ? sig(supervisorName ?? "Supervisor") : null,
        approved ? stamp : null,
        approved ? "10.4.12.18" : null,
        approved ? "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)" : null,
        rejected ? rec.reason ?? null : null,
        rejected ? stamp : null,
        rejected ? supervisor : null,
        rejected ? supervisorName : null,
      ],
    );
  }

  const attendance: { id: string; worker: string; date: string; status: "present" | "absent"; in?: string; out?: string }[] = [
    { id: "att-1", worker: "demo-worker-1", date: "2026-10-01", status: "present", in: "08:00", out: "17:00" },
    { id: "att-2", worker: "demo-worker-2", date: "2026-10-01", status: "present", in: "08:00", out: "17:00" },
    { id: "att-3", worker: "demo-worker-3", date: "2026-10-01", status: "absent" },
    { id: "att-4", worker: "demo-worker-4", date: "2026-09-30", status: "present", in: "22:00", out: "06:00" },
  ];
  for (const a of attendance) {
    let hours: number | null = null;
    if (a.in && a.out) {
      hours = calculateOvertimeHours(a.in, a.out).hours;
    }
    await sql.query(
      `insert into attendance (id, worker_user_id, work_date, status, clock_in, clock_out, hours)
       values ($1,$2,$3,$4,$5,$6,$7) on conflict (worker_user_id, work_date) do nothing`,
      [a.id, a.worker, a.date, a.status, a.in ?? null, a.out ?? null, hours],
    );
  }

  await sql.query(
    `insert into audit_logs (id, actor_user_id, actor_name, actor_role, action, entity_type, entity_id, details)
     values ($1,$2,$3,$4,'system.seed_demo','company','northline',$5)`,
    [
      crypto.randomUUID(),
      actor.userId,
      actor.fullName,
      actor.role,
      JSON.stringify({ workers: 6, supervisors: 2, records: RECORDS.length, links: true }),
    ],
  );
}
