const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

export function parseMinutes(time: string): number {
  const match = TIME_RE.exec(time);
  if (!match) throw new Error("Enter times as HH:MM (24-hour).");
  return Number(match[1]) * 60 + Number(match[2]);
}

export function isValidTime(time: string): boolean {
  return TIME_RE.test(time);
}

export function calculateOvertimeHours(
  startTime: string,
  endTime: string,
): { hours: number; crossesMidnight: boolean; minutes: number } {
  const start = parseMinutes(startTime);
  const end = parseMinutes(endTime);
  if (start === end) {
    throw new Error("Start and end time cannot be the same.");
  }
  const crossesMidnight = end < start;
  const minutes = crossesMidnight ? end + 24 * 60 - start : end - start;
  if (minutes <= 0 || minutes > 24 * 60) {
    throw new Error("Overtime duration must be between 1 minute and 24 hours.");
  }
  const hours = Math.round((minutes / 60) * 100) / 100;
  return { hours, crossesMidnight, minutes };
}

/** Inclusive ranges in minutes from work_date midnight. End may exceed 24h. */
export function overtimeRange(
  workDate: string,
  startTime: string,
  endTime: string,
): { start: number; end: number } {
  const { crossesMidnight } = calculateOvertimeHours(startTime, endTime);
  const day = Date.parse(`${workDate}T00:00:00Z`);
  if (Number.isNaN(day)) throw new Error("Invalid date.");
  const start = day + parseMinutes(startTime) * 60_000;
  const end = day + (parseMinutes(endTime) + (crossesMidnight ? 24 * 60 : 0)) * 60_000;
  return { start, end };
}

export function rangesOverlap(
  a: { start: number; end: number },
  b: { start: number; end: number },
): boolean {
  return a.start < b.end && b.start < a.end;
}

export function formatTime12(time: string): string {
  if (!TIME_RE.test(time)) return time;
  const [h, m] = time.split(":").map(Number);
  const period = h < 12 ? "AM" : "PM";
  const hour = h % 12 || 12;
  return `${hour}:${String(m).padStart(2, "0")} ${period}`;
}

export function formatHours(hours: number): string {
  const n = Math.round(hours * 100) / 100;
  const whole = Number.isInteger(n);
  const label = whole ? String(n) : n.toFixed(2);
  return `${label} ${n === 1 ? "hour" : "hours"}`;
}

export function currentMonthKey(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function monthBounds(monthKey: string): { from: string; to: string; label: string } {
  const [yearStr, monthStr] = monthKey.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);
  if (!year || !month || month < 1 || month > 12) throw new Error("Invalid month.");
  const last = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const from = `${yearStr}-${monthStr}-01`;
  const to = `${yearStr}-${monthStr}-${String(last).padStart(2, "0")}`;
  const label = new Date(year, month - 1, 1).toLocaleString("en-GB", {
    month: "long",
    year: "numeric",
  });
  return { from, to, label };
}

export function shiftMonth(monthKey: string, delta: number): string {
  const [y, m] = monthKey.split("-").map(Number);
  const date = new Date(y, m - 1 + delta, 1);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}
