import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import {
  AppError,
  ATTENDANCE_SELECT,
  OT_SELECT,
  getSetting,
  loadWorkerByToken,
  mapAttendance,
  mapOvertime,
  newId,
  writeAudit,
} from "./access";
import { calculateOvertimeHours, monthBounds, overtimeRange, rangesOverlap } from "./hours";
import type { AttendanceStatus } from "./types";

function fail(err: unknown): never {
  if (err instanceof AppError) throw err;
  if (err instanceof Error) throw new AppError(err.message);
  throw new AppError("Something went wrong.");
}

async function assertNoOverlap(workerId: string, date: string, start: string, end: string, exceptId?: string) {
  const sql = await getSql();
  const rows = await sql.query<{ id: string; work_date: string; start_time: string; end_time: string }>(
    `select id, work_date, start_time, end_time from overtime_records
     where worker_user_id = $1 and status in ('pending','approved')
       and work_date between ($2::date - interval '1 day') and ($2::date + interval '1 day')
       ${exceptId ? "and id <> $3" : ""}`,
    exceptId ? [workerId, date, exceptId] : [workerId, date],
  );
  const next = overtimeRange(date, start, end);
  for (const row of rows) {
    const existing = overtimeRange(String(row.work_date).slice(0, 10), row.start_time, row.end_time);
    if (rangesOverlap(next, existing)) {
      throw new AppError("This overtime overlaps an existing pending or approved entry.");
    }
  }
}

export const loadWorkerPortal = createServerFn({ method: "GET" })
  .validator((token: string) => token)
  .handler(async ({ data: token }) => {
    try {
      const { worker, companyName } = await loadWorkerByToken(token);
      return { token, companyName, worker };
    } catch (err) {
      fail(err);
    }
  });

export const listWorkerOvertime = createServerFn({ method: "GET" })
  .validator((input: { token: string; month?: string }) => input)
  .handler(async ({ data }) => {
    try {
      const { worker } = await loadWorkerByToken(data.token);
      const sql = await getSql();
      const params: unknown[] = [worker.userId];
      let extra = "";
      if (data.month) {
        const { from, to } = monthBounds(data.month);
        params.push(from, to);
        extra = ` and o.work_date between $2 and $3`;
      }
      const rows = await sql.query(
        `${OT_SELECT} where o.worker_user_id = $1${extra} order by o.work_date desc, o.start_time desc`,
        params,
      );
      return rows.map((row) => mapOvertime(row as Parameters<typeof mapOvertime>[0]));
    } catch (err) {
      fail(err);
    }
  });

export const listWorkerAttendance = createServerFn({ method: "GET" })
  .validator((input: { token: string; month?: string }) => input)
  .handler(async ({ data }) => {
    try {
      const { worker } = await loadWorkerByToken(data.token);
      const sql = await getSql();
      const params: unknown[] = [worker.userId];
      let extra = "";
      if (data.month) {
        const { from, to } = monthBounds(data.month);
        params.push(from, to);
        extra = ` and a.work_date between $2 and $3`;
      }
      const rows = await sql.query(
        `${ATTENDANCE_SELECT} where a.worker_user_id = $1${extra} order by a.work_date desc`,
        params,
      );
      return rows.map((row) => mapAttendance(row as Parameters<typeof mapAttendance>[0]));
    } catch (err) {
      fail(err);
    }
  });

type MarkAttendanceInput = {
  token: string;
  date: string;
  status: AttendanceStatus;
  clockIn?: string;
  clockOut?: string;
  notes?: string;
};

export const markWorkerAttendance = createServerFn({ method: "POST" })
  .validator((input: MarkAttendanceInput) => input)
  .handler(async ({ data }) => {
    try {
      const { worker } = await loadWorkerByToken(data.token);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(data.date)) throw new AppError("Choose a valid date.");
      if (data.status !== "present" && data.status !== "absent") {
        throw new AppError("Mark present or absent.");
      }
      const clockIn = data.status === "present" ? data.clockIn?.trim() || null : null;
      const clockOut = data.status === "present" ? data.clockOut?.trim() || null : null;
      let hours: number | null = null;
      if (clockIn && clockOut) {
        hours = calculateOvertimeHours(clockIn, clockOut).hours;
      }
      const sql = await getSql();
      const existing = await sql.query<{ id: string }>(
        `select id from attendance where worker_user_id = $1 and work_date = $2`,
        [worker.userId, data.date],
      );
      const id = existing[0]?.id ?? newId();
      if (existing[0]) {
        await sql.query(
          `update attendance
           set status=$2, clock_in=$3, clock_out=$4, hours=$5, notes=$6, updated_at=now()
           where id=$1`,
          [id, data.status, clockIn, clockOut, hours, data.notes?.trim() || null],
        );
      } else {
        await sql.query(
          `insert into attendance (id, worker_user_id, work_date, status, clock_in, clock_out, hours, notes)
           values ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [id, worker.userId, data.date, data.status, clockIn, clockOut, hours, data.notes?.trim() || null],
        );
      }
      return { id };
    } catch (err) {
      fail(err);
    }
  });

type WorkerOtInput = {
  token: string;
  date: string;
  startTime: string;
  endTime: string;
  description?: string;
  id?: string;
};

export const submitWorkerOvertime = createServerFn({ method: "POST" })
  .validator((input: WorkerOtInput) => input)
  .handler(async ({ data }) => {
    try {
      const { worker } = await loadWorkerByToken(data.token);
      if (!worker.supervisorUserId) {
        throw new AppError("You must be assigned to a supervisor before submitting overtime.");
      }
      const required = await getSetting("require_description", "false");
      if (required === "true" && !data.description?.trim()) {
        throw new AppError("A description is required.");
      }
      const { hours, crossesMidnight } = calculateOvertimeHours(data.startTime, data.endTime);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(data.date)) throw new AppError("Choose a valid date.");
      await assertNoOverlap(worker.userId, data.date, data.startTime, data.endTime, data.id);
      const sql = await getSql();
      const description = data.description?.trim() || null;
      if (data.id) {
        const existing = await sql.query<{ status: string; worker_user_id: string }>(
          `select status, worker_user_id from overtime_records where id = $1`,
          [data.id],
        );
        if (!existing[0] || existing[0].worker_user_id !== worker.userId) {
          throw new AppError("Overtime record not found.", 404);
        }
        if (existing[0].status !== "pending") {
          throw new AppError("Approved or rejected overtime cannot be edited.");
        }
        await sql.query(
          `update overtime_records
           set work_date=$2, start_time=$3, end_time=$4, total_hours=$5, crosses_midnight=$6,
               description=$7, department_id=$8, supervisor_user_id=$9, updated_at=now()
           where id=$1`,
          [
            data.id,
            data.date,
            data.startTime,
            data.endTime,
            hours,
            crossesMidnight,
            description,
            worker.departmentId,
            worker.supervisorUserId,
          ],
        );
        return { id: data.id };
      }
      const id = newId();
      await sql.query(
        `insert into overtime_records (
          id, worker_user_id, work_date, start_time, end_time, total_hours, crosses_midnight,
          description, status, department_id, supervisor_user_id
        ) values ($1,$2,$3,$4,$5,$6,$7,$8,'pending',$9,$10)`,
        [
          id,
          worker.userId,
          data.date,
          data.startTime,
          data.endTime,
          hours,
          crossesMidnight,
          description,
          worker.departmentId,
          worker.supervisorUserId,
        ],
      );
      await writeAudit({
        actor: worker,
        action: "overtime.submitted",
        entityType: "overtime",
        entityId: id,
        details: { date: data.date, hours, via: "worker_link" },
      });
      return { id };
    } catch (err) {
      fail(err);
    }
  });

export const withdrawWorkerOvertime = createServerFn({ method: "POST" })
  .validator((input: { token: string; id: string }) => input)
  .handler(async ({ data }) => {
    try {
      const { worker } = await loadWorkerByToken(data.token);
      const sql = await getSql();
      const rows = await sql.query<{ status: string; worker_user_id: string }>(
        `select status, worker_user_id from overtime_records where id = $1`,
        [data.id],
      );
      if (!rows[0] || rows[0].worker_user_id !== worker.userId) throw new AppError("Record not found.", 404);
      if (rows[0].status !== "pending") throw new AppError("Only pending overtime can be withdrawn.");
      await sql.query(`delete from overtime_records where id = $1`, [data.id]);
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });
