import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { APP_NAME } from "@/lib/brand";
import { getSql } from "@/lib/db";
import {
  AppError,
  ATTENDANCE_SELECT,
  OT_SELECT,
  assertCanViewWorker,
  clientMeta,
  createAuthUser,
  getSetting,
  hashUserPassword,
  issueWorkerLink,
  listDepartmentsRows,
  loadActiveWorkerToken,
  loadProfile,
  mapAttendance,
  mapOvertime,
  mapProfile,
  mapSummary,
  newId,
  nextEmployeeId,
  num,
  overtimeScopeSql,
  requireActive,
  requireRole,
  resolveActor,
  writeAudit,
} from "./access";
import { buildOvertimeWorkbook } from "./excel";
import { calculateOvertimeHours, monthBounds, overtimeRange, rangesOverlap } from "./hours";
import { seedDemoCompany } from "./seed";
import type { Actor, OtFilters, OtStatus, OvertimeRecord, Role } from "./types";
import { canAddWorkers, canExport, canManageAdmins, canManageUsers, isAdminRole } from "./types";

function fail(err: unknown): never {
  if (err instanceof AppError) throw err;
  if (err instanceof Error) throw new AppError(err.message);
  throw new AppError("Something went wrong.");
}

async function actorOf(userId: string): Promise<Actor> {
  const actor = await resolveActor(userId);
  return actor;
}

export const loadSession = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    return actorOf(context.userId);
  });

export const listDepartments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    return listDepartmentsRows(false);
  });

export const listUsers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: { role?: Role | Role[] } = {}) => input)
  .handler(async ({ context, data }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const sql = await getSql();
    const roles = data.role ? (Array.isArray(data.role) ? data.role : [data.role]) : null;
    const params: unknown[] = [];
    const where: string[] = [];
    if (roles && roles.length) {
      const placeholders = roles.map((_, i) => `$${params.length + i + 1}`).join(", ");
      params.push(...roles);
      where.push(`p.role in (${placeholders})`);
    }
    if (acting.role === "supervisor") {
      params.push(acting.userId);
      where.push(`p.supervisor_user_id = $${params.length}`);
    } else if (acting.role === "worker") {
      params.push(acting.userId);
      where.push(`p.user_id = $${params.length}`);
    }
    const clause = where.length ? `where ${where.join(" and ")}` : "";
    const rows = await sql.query<{
      user_id: string;
      role: Role;
      full_name: string;
      employee_id: string | null;
      department_id: string | null;
      department_name: string | null;
      supervisor_user_id: string | null;
      supervisor_name: string | null;
      phone: string | null;
      is_active: boolean;
      email: string | null;
      created_at: string;
    }>(
      `select p.user_id, p.role, p.full_name, p.employee_id, p.department_id, d.name as department_name,
              p.supervisor_user_id, s.full_name as supervisor_name, p.phone, p.is_active, u.email, p.created_at
       from profiles p
       left join departments d on d.id = p.department_id
       left join profiles s on s.user_id = p.supervisor_user_id
       left join "user" u on u.id = p.user_id
       ${clause}
       order by p.full_name`,
      params,
    );
    return rows.map(mapProfile);
  });

export const getUser = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const profile = await loadProfile(id);
    if (!profile) throw new AppError("User not found.", 404);
    if (acting.role === "worker" && profile.userId !== acting.userId) {
      throw new AppError("You can only view your own profile.", 403);
    }
    if (acting.role === "supervisor" && profile.userId !== acting.userId && profile.supervisorUserId !== acting.userId) {
      throw new AppError("You can only view workers assigned to you.", 403);
    }
    return profile;
  });

type CreateUserInput = {
  name: string;
  email: string;
  password: string;
  role: Role;
  departmentId?: string | null;
  supervisorUserId?: string | null;
  employeeId?: string | null;
  phone?: string | null;
};

export const createUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: CreateUserInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["super_admin", "admin"]);
      if (data.role === "super_admin" && acting.role !== "super_admin") {
        throw new AppError("Only a Super Admin can create Super Admins.", 403);
      }
      if (data.role === "admin" && acting.role !== "super_admin") {
        throw new AppError("Only a Super Admin can create Admins.", 403);
      }
      if (data.role === "worker") {
        throw new AppError("Workers do not get login accounts. Add them from People and share their personal link.");
      }
      const name = data.name.trim();
      const email = data.email.trim().toLowerCase();
      if (!name) throw new AppError("Name is required.");
      if (!email.includes("@")) throw new AppError("A valid email is required.");
      const id = newId();
      const prefix = data.role === "supervisor" ? "SV" : "AD";
      const employeeId = data.employeeId?.trim() || (await nextEmployeeId(prefix));
      const hash = await hashUserPassword(data.password);
      await createAuthUser({ id, name, email, passwordHash: hash });
      const sql = await getSql();
      await sql.query(
        `insert into profiles (user_id, role, full_name, employee_id, department_id, supervisor_user_id, phone, is_active, created_by)
         values ($1,$2,$3,$4,$5,$6,$7,true,$8)`,
        [
          id,
          data.role,
          name,
          employeeId,
          data.departmentId || null,
          null,
          data.phone?.trim() || null,
          acting.userId,
        ],
      );
      await writeAudit({
        actor: acting,
        action: "user.created",
        entityType: "profile",
        entityId: id,
        details: { email, role: data.role, employeeId },
      });
      return loadProfile(id);
    } catch (err) {
      fail(err);
    }
  });

type CreateWorkerInput = {
  name: string;
  departmentId?: string | null;
  supervisorUserId?: string | null;
  employeeId?: string | null;
  phone?: string | null;
};

export const createWorker = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: CreateWorkerInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireActive(acting);
      if (!canAddWorkers(acting.role)) {
        throw new AppError("Only supervisors and admins can add workers.", 403);
      }
      const name = data.name.trim();
      if (!name) throw new AppError("Name is required.");
      const supervisorUserId =
        acting.role === "supervisor" ? acting.userId : data.supervisorUserId?.trim() || null;
      if (!supervisorUserId) throw new AppError("Workers must be assigned to a supervisor.");
      const supervisor = await loadProfile(supervisorUserId);
      if (!supervisor || supervisor.role !== "supervisor") {
        throw new AppError("Choose a valid supervisor.");
      }
      const id = newId();
      const employeeId = data.employeeId?.trim() || (await nextEmployeeId("EMP"));
      const sql = await getSql();
      await sql.query(
        `insert into profiles (user_id, role, full_name, employee_id, department_id, supervisor_user_id, phone, is_active, created_by)
         values ($1,'worker',$2,$3,$4,$5,$6,true,$7)`,
        [id, name, employeeId, data.departmentId || null, supervisorUserId, data.phone?.trim() || null, acting.userId],
      );
      const token = await issueWorkerLink(id);
      await writeAudit({
        actor: acting,
        action: "worker.created",
        entityType: "profile",
        entityId: id,
        details: { employeeId, supervisorUserId },
      });
      const profile = await loadProfile(id);
      return { profile, token, path: `/w/${token}` };
    } catch (err) {
      fail(err);
    }
  });

export const getWorkerLink = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((workerUserId: string) => workerUserId)
  .handler(async ({ context, data: workerUserId }) => {
    try {
      const { acting } = await actorOf(context.userId);
      const worker = await loadProfile(workerUserId);
      if (!worker || worker.role !== "worker") throw new AppError("Worker not found.", 404);
      assertCanViewWorker(acting, worker);
      let token = await loadActiveWorkerToken(workerUserId);
      if (!token) token = await issueWorkerLink(workerUserId);
      return { token, path: `/w/${token}`, workerName: worker.fullName };
    } catch (err) {
      fail(err);
    }
  });

export const regenerateWorkerLink = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((workerUserId: string) => workerUserId)
  .handler(async ({ context, data: workerUserId }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireActive(acting);
      const worker = await loadProfile(workerUserId);
      if (!worker || worker.role !== "worker") throw new AppError("Worker not found.", 404);
      assertCanViewWorker(acting, worker);
      if (acting.role === "worker") throw new AppError("Workers cannot rotate their own link.", 403);
      const token = await issueWorkerLink(workerUserId);
      await writeAudit({
        actor: acting,
        action: "worker.link_rotated",
        entityType: "profile",
        entityId: workerUserId,
      });
      return { token, path: `/w/${token}`, workerName: worker.fullName };
    } catch (err) {
      fail(err);
    }
  });

export const listAttendance = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((filters: { month?: string; workerUserId?: string } = {}) => filters)
  .handler(async ({ context, data: filters }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const sql = await getSql();
    const scope = overtimeScopeSql(acting, "a");
    const params = [...scope.params];
    const where = [scope.sql];
    if (filters.month) {
      const { from, to } = monthBounds(filters.month);
      params.push(from, to);
      where.push(`a.work_date between $${params.length - 1} and $${params.length}`);
    }
    if (filters.workerUserId) {
      params.push(filters.workerUserId);
      where.push(`a.worker_user_id = $${params.length}`);
    }
    const rows = await sql.query(
      `${ATTENDANCE_SELECT} where ${where.join(" and ")} order by a.work_date desc, w.full_name`,
      params,
    );
    return rows.map((row) => mapAttendance(row as Parameters<typeof mapAttendance>[0]));
  });

type UpdateUserInput = {
  userId: string;
  name?: string;
  role?: Role;
  departmentId?: string | null;
  supervisorUserId?: string | null;
  employeeId?: string | null;
  phone?: string | null;
  isActive?: boolean;
};

export const updateUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: UpdateUserInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireActive(acting);
      const existing = await loadProfile(data.userId);
      if (!existing) throw new AppError("User not found.", 404);
      const supervisorOwnsWorker =
        acting.role === "supervisor" && existing.role === "worker" && existing.supervisorUserId === acting.userId;
      if (!isAdminRole(acting.role) && !supervisorOwnsWorker) {
        throw new AppError("You do not have permission to edit this person.", 403);
      }
      if (existing.role === "super_admin" && acting.role !== "super_admin") {
        throw new AppError("You cannot edit a Super Admin.", 403);
      }
      if ((data.role === "admin" || data.role === "super_admin") && acting.role !== "super_admin") {
        throw new AppError("Only a Super Admin can assign that role.", 403);
      }
      if (acting.role === "supervisor" && data.role && data.role !== "worker") {
        throw new AppError("Supervisors can only manage workers.", 403);
      }
      const sql = await getSql();
      const name = data.name?.trim() || existing.fullName;
      const role = acting.role === "supervisor" ? existing.role : (data.role ?? existing.role);
      const departmentId = data.departmentId === undefined ? existing.departmentId : data.departmentId;
      const supervisorUserId =
        role === "worker"
          ? acting.role === "supervisor"
            ? existing.supervisorUserId
            : data.supervisorUserId === undefined
              ? existing.supervisorUserId
              : data.supervisorUserId
          : null;
      if (role === "worker" && !supervisorUserId) {
        throw new AppError("Workers must be assigned to a supervisor.");
      }
      await sql.query(
        `update profiles
         set full_name = $2, role = $3, department_id = $4, supervisor_user_id = $5,
             employee_id = $6, phone = $7, is_active = $8, updated_at = now()
         where user_id = $1`,
        [
          data.userId,
          name,
          role,
          departmentId,
          supervisorUserId,
          data.employeeId === undefined ? existing.employeeId : data.employeeId,
          data.phone === undefined ? existing.phone : data.phone,
          data.isActive ?? existing.isActive,
        ],
      );
      await sql.query(`update "user" set name = $2, "updatedAt" = now() where id = $1`, [data.userId, name]);
      await writeAudit({
        actor: acting,
        action: "user.updated",
        entityType: "profile",
        entityId: data.userId,
        details: { role, isActive: data.isActive ?? existing.isActive },
      });
      return loadProfile(data.userId);
    } catch (err) {
      fail(err);
    }
  });

export const resetUserPassword = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; password: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["super_admin", "admin"]);
      const existing = await loadProfile(data.userId);
      if (!existing) throw new AppError("User not found.", 404);
      if (existing.role === "super_admin" && acting.role !== "super_admin") {
        throw new AppError("You cannot reset a Super Admin password.", 403);
      }
      const hash = await hashUserPassword(data.password);
      const sql = await getSql();
      const now = new Date().toISOString();
      const existingAcc = await sql.query<{ id: string }>(
        `select id from "account" where "userId" = $1 and "providerId" = 'credential'`,
        [data.userId],
      );
      if (existingAcc[0]) {
        await sql.query(
          `update "account" set password = $2, "updatedAt" = $3 where id = $1`,
          [existingAcc[0].id, hash, now],
        );
      } else {
        await sql.query(
          `insert into "account" (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
           values ($1,$2,'credential',$3,$4,$5,$5)`,
          [newId(), data.userId, data.userId, hash, now],
        );
      }
      await writeAudit({
        actor: acting,
        action: "user.password_reset",
        entityType: "profile",
        entityId: data.userId,
      });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

export const createDepartment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; code?: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["super_admin", "admin"]);
      const name = data.name.trim();
      if (!name) throw new AppError("Department name is required.");
      const sql = await getSql();
      const id = newId();
      await sql.query(`insert into departments (id, name, code) values ($1,$2,$3)`, [
        id,
        name,
        data.code?.trim() || null,
      ]);
      await writeAudit({
        actor: acting,
        action: "department.created",
        entityType: "department",
        entityId: id,
        details: { name },
      });
      return { id, name, code: data.code?.trim() || null, isActive: true };
    } catch (err) {
      fail(err);
    }
  });

export const updateDepartment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; name?: string; code?: string | null; isActive?: boolean }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["super_admin", "admin"]);
      const sql = await getSql();
      const current = await sql.query<{ name: string; code: string | null; is_active: boolean }>(
        `select name, code, is_active from departments where id = $1`,
        [data.id],
      );
      if (!current[0]) throw new AppError("Department not found.", 404);
      await sql.query(`update departments set name = $2, code = $3, is_active = $4 where id = $1`, [
        data.id,
        data.name?.trim() || current[0].name,
        data.code === undefined ? current[0].code : data.code,
        data.isActive ?? current[0].is_active,
      ]);
      await writeAudit({
        actor: acting,
        action: "department.updated",
        entityType: "department",
        entityId: data.id,
      });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

type SubmitInput = {
  date: string;
  startTime: string;
  endTime: string;
  description?: string;
  id?: string;
};

async function assertNoOverlap(workerId: string, date: string, start: string, end: string, exceptId?: string) {
  const sql = await getSql();
  const rows = await sql.query<{ id: string; work_date: string; start_time: string; end_time: string }>(
    `select id, work_date, start_time, end_time from overtime_records
     where worker_user_id = $1 and status in ('pending','approved')
       and work_date between ($2::date - interval '1 day') and ($2::date + interval '1 day')
       ${exceptId ? "and id <> $3" : ""}`,
    exceptId ? [workerId, date, exceptId] : [workerId, date],
  );
  const next = overtimeRange(date, start, end);
  for (const row of rows) {
    const existing = overtimeRange(String(row.work_date).slice(0, 10), row.start_time, row.end_time);
    if (rangesOverlap(next, existing)) {
      throw new AppError("This overtime overlaps an existing pending or approved entry.");
    }
  }
}

export const submitOvertime = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: SubmitInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["worker"]);
      if (!acting.supervisorUserId) {
        throw new AppError("You must be assigned to a supervisor before submitting overtime.");
      }
      const required = await getSetting("require_description", "false");
      if (required === "true" && !data.description?.trim()) {
        throw new AppError("A description is required.");
      }
      const { hours, crossesMidnight } = calculateOvertimeHours(data.startTime, data.endTime);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(data.date)) throw new AppError("Choose a valid date.");
      await assertNoOverlap(acting.userId, data.date, data.startTime, data.endTime, data.id);
      const sql = await getSql();
      const description = data.description?.trim() || null;
      if (data.id) {
        const existing = await sql.query<{ status: OtStatus; worker_user_id: string }>(
          `select status, worker_user_id from overtime_records where id = $1`,
          [data.id],
        );
        if (!existing[0] || existing[0].worker_user_id !== acting.userId) {
          throw new AppError("Overtime record not found.", 404);
        }
        if (existing[0].status !== "pending") {
          throw new AppError("Approved or rejected overtime cannot be edited.");
        }
        await sql.query(
          `update overtime_records
           set work_date=$2, start_time=$3, end_time=$4, total_hours=$5, crosses_midnight=$6,
               description=$7, department_id=$8, supervisor_user_id=$9, updated_at=now()
           where id=$1`,
          [
            data.id,
            data.date,
            data.startTime,
            data.endTime,
            hours,
            crossesMidnight,
            description,
            acting.departmentId,
            acting.supervisorUserId,
          ],
        );
        await writeAudit({
          actor: acting,
          action: "overtime.updated",
          entityType: "overtime",
          entityId: data.id,
        });
        return { id: data.id };
      }
      const id = newId();
      await sql.query(
        `insert into overtime_records (
          id, worker_user_id, work_date, start_time, end_time, total_hours, crosses_midnight,
          description, status, department_id, supervisor_user_id
        ) values ($1,$2,$3,$4,$5,$6,$7,$8,'pending',$9,$10)`,
        [
          id,
          acting.userId,
          data.date,
          data.startTime,
          data.endTime,
          hours,
          crossesMidnight,
          description,
          acting.departmentId,
          acting.supervisorUserId,
        ],
      );
      await writeAudit({
        actor: acting,
        action: "overtime.submitted",
        entityType: "overtime",
        entityId: id,
        details: { date: data.date, hours },
      });
      return { id };
    } catch (err) {
      fail(err);
    }
  });

export const withdrawOvertime = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["worker"]);
      const sql = await getSql();
      const rows = await sql.query<{ status: OtStatus; worker_user_id: string }>(
        `select status, worker_user_id from overtime_records where id = $1`,
        [id],
      );
      if (!rows[0] || rows[0].worker_user_id !== acting.userId) throw new AppError("Record not found.", 404);
      if (rows[0].status !== "pending") throw new AppError("Only pending overtime can be withdrawn.");
      await sql.query(`delete from overtime_records where id = $1`, [id]);
      await writeAudit({ actor: acting, action: "overtime.withdrawn", entityType: "overtime", entityId: id });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

async function authorizeRecord(acting: Actor["acting"], rec: OvertimeRecord): Promise<void> {
  if (isAdminRole(acting.role)) return;
  if (acting.role === "worker") {
    if (rec.workerUserId !== acting.userId) throw new AppError("You can only view your own overtime.", 403);
    return;
  }
  if (acting.role === "supervisor") {
    const worker = await loadProfile(rec.workerUserId);
    if (worker?.supervisorUserId === acting.userId || rec.supervisorUserId === acting.userId) return;
    throw new AppError("You can only view overtime for workers assigned to you.", 403);
  }
  throw new AppError("You do not have permission to view that record.", 403);
}

export const getOvertime = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const actor = await actorOf(context.userId);
    requireActive(actor.acting);
    const sql = await getSql();
    const rows = await sql.query(`${OT_SELECT} where o.id = $1`, [id]);
    if (!rows[0]) throw new AppError("Record not found.", 404);
    const rec = mapOvertime(rows[0] as Parameters<typeof mapOvertime>[0]);
    await authorizeRecord(actor.acting, rec);
    return rec;
  });

export const listOvertime = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((filters: OtFilters = {}) => filters)
  .handler(async ({ context, data: filters }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const sql = await getSql();
    const scope = overtimeScopeSql(acting);
    const params = [...scope.params];
    const where = [scope.sql];
    const add = (fragment: string, value: unknown) => {
      params.push(value);
      where.push(fragment.replace("?", `$${params.length}`));
    };
    if (filters.month) {
      const { from, to } = monthBounds(filters.month);
      add("o.work_date >= ?", from);
      add("o.work_date <= ?", to);
    }
    if (filters.from) add("o.work_date >= ?", filters.from);
    if (filters.to) add("o.work_date <= ?", filters.to);
    if (filters.workerUserId) add("o.worker_user_id = ?", filters.workerUserId);
    if (filters.employeeId) add("w.employee_id ilike ?", `%${filters.employeeId.trim()}%`);
    if (filters.supervisorUserId) add("o.supervisor_user_id = ?", filters.supervisorUserId);
    if (filters.departmentId) add("o.department_id = ?", filters.departmentId);
    if (filters.status) add("o.status = ?", filters.status);
    const rows = await sql.query(
      `${OT_SELECT} where ${where.join(" and ")} order by o.work_date desc, o.start_time desc`,
      params,
    );
    return rows.map((row) => mapOvertime(row as Parameters<typeof mapOvertime>[0]));
  });

export const approveOvertime = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; signatureData: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireActive(acting);
      if (acting.role === "worker") throw new AppError("Workers cannot approve overtime.", 403);
      const sql = await getSql();
      const rows = await sql.query<{
        status: OtStatus;
        worker_user_id: string;
        supervisor_user_id: string | null;
      }>(`select status, worker_user_id, supervisor_user_id from overtime_records where id = $1`, [data.id]);
      const rec = rows[0];
      if (!rec) throw new AppError("Record not found.", 404);
      if (rec.worker_user_id === acting.userId) {
        throw new AppError("You cannot approve your own overtime.", 403);
      }
      if (rec.status !== "pending") throw new AppError("Only pending overtime can be approved.");
      const worker = await loadProfile(rec.worker_user_id);
      if (!worker) throw new AppError("Worker not found.", 404);
      const assignedToActor = worker.supervisorUserId === acting.userId;
      if (!assignedToActor && !isAdminRole(acting.role)) {
        throw new AppError("You can only approve overtime for workers assigned to you.", 403);
      }
      if (!data.signatureData || data.signatureData.length < 80) {
        throw new AppError("A signature is required to approve overtime.");
      }
      const meta = clientMeta();
      await sql.query(
        `update overtime_records set
           status = 'approved',
           approved_by_user_id = $2,
           approved_by_name = $3,
           signature_data = $4,
           approved_at = now(),
           approval_ip = $5,
           approval_user_agent = $6,
           rejection_reason = null,
           rejected_at = null,
           rejected_by_user_id = null,
           rejected_by_name = null,
           updated_at = now()
         where id = $1`,
        [data.id, acting.userId, acting.fullName, data.signatureData, meta.ip, meta.userAgent],
      );
      await writeAudit({
        actor: acting,
        action: "overtime.approved",
        entityType: "overtime",
        entityId: data.id,
        details: { worker: worker.fullName, override: !assignedToActor },
      });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

export const rejectOvertime = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; reason: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireActive(acting);
      if (acting.role === "worker") throw new AppError("Workers cannot reject overtime.", 403);
      const reason = data.reason.trim();
      if (reason.length < 3) throw new AppError("A rejection reason is required.");
      const sql = await getSql();
      const rows = await sql.query<{
        status: OtStatus;
        worker_user_id: string;
      }>(`select status, worker_user_id from overtime_records where id = $1`, [data.id]);
      const rec = rows[0];
      if (!rec) throw new AppError("Record not found.", 404);
      if (rec.worker_user_id === acting.userId) {
        throw new AppError("You cannot reject your own overtime.", 403);
      }
      if (rec.status !== "pending") throw new AppError("Only pending overtime can be rejected.");
      const worker = await loadProfile(rec.worker_user_id);
      if (!worker) throw new AppError("Worker not found.", 404);
      const assignedToActor = worker.supervisorUserId === acting.userId;
      if (!assignedToActor && !isAdminRole(acting.role)) {
        throw new AppError("You can only reject overtime for workers assigned to you.", 403);
      }
      await sql.query(
        `update overtime_records set
           status = 'rejected',
           rejection_reason = $2,
           rejected_at = now(),
           rejected_by_user_id = $3,
           rejected_by_name = $4,
           signature_data = null,
           approved_at = null,
           approved_by_user_id = null,
           approved_by_name = null,
           updated_at = now()
         where id = $1`,
        [data.id, reason, acting.userId, acting.fullName],
      );
      await writeAudit({
        actor: acting,
        action: "overtime.rejected",
        entityType: "overtime",
        entityId: data.id,
        details: { worker: worker.fullName, reason },
      });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

export const dashboardStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((month: string) => month)
  .handler(async ({ context, data: month }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const { from, to } = monthBounds(month);
    const sql = await getSql();
    const scope = overtimeScopeSql(acting);
    const params = [...scope.params, from, to];
    const fromP = `$${scope.params.length + 1}`;
    const toP = `$${scope.params.length + 2}`;
    const counts = await sql.query<{
      pending_count: number;
      approved_count: number;
      rejected_count: number;
      pending_hours: unknown;
      approved_hours: unknown;
      total_hours: unknown;
    }>(
      `select
         count(*) filter (where o.status = 'pending')::int as pending_count,
         count(*) filter (where o.status = 'approved')::int as approved_count,
         count(*) filter (where o.status = 'rejected')::int as rejected_count,
         coalesce(sum(o.total_hours) filter (where o.status = 'pending'), 0) as pending_hours,
         coalesce(sum(o.total_hours) filter (where o.status = 'approved'), 0) as approved_hours,
         coalesce(sum(o.total_hours) filter (where o.status <> 'rejected'), 0) as total_hours
       from overtime_records o
       where ${scope.sql} and o.work_date between ${fromP} and ${toP}`,
      params,
    );
    let workerWhere = "role = 'worker' and is_active = true";
    const workerParams: unknown[] = [];
    if (acting.role === "supervisor") {
      workerParams.push(acting.userId);
      workerWhere += ` and supervisor_user_id = $1`;
    } else if (acting.role === "worker") {
      workerParams.push(acting.userId);
      workerWhere += ` and user_id = $1`;
    }
    const workers = await sql.query<{ n: number }>(
      `select count(*)::int as n from profiles where ${workerWhere}`,
      workerParams,
    );
    const daily = await sql.query<{ date: string; hours: unknown }>(
      `select o.work_date::text as date, coalesce(sum(o.total_hours),0) as hours
       from overtime_records o
       where ${scope.sql} and o.work_date between ${fromP} and ${toP} and o.status <> 'rejected'
       group by o.work_date order by o.work_date`,
      params,
    );
    const c = counts[0];
    let presentDays = 0;
    let absentDays = 0;
    const attScope = overtimeScopeSql(acting, "a");
    const attParams = [...attScope.params, from, to];
    const attFrom = `$${attScope.params.length + 1}`;
    const attTo = `$${attScope.params.length + 2}`;
    const att = await sql.query<{ present_days: number; absent_days: number }>(
      `select
         count(*) filter (where a.status = 'present')::int as present_days,
         count(*) filter (where a.status = 'absent')::int as absent_days
       from attendance a
       where ${attScope.sql} and a.work_date between ${attFrom} and ${attTo}`,
      attParams,
    );
    presentDays = att[0]?.present_days ?? 0;
    absentDays = att[0]?.absent_days ?? 0;
    return {
      month,
      totalWorkers: workers[0]?.n ?? 0,
      totalHours: num(c?.total_hours),
      pendingCount: c?.pending_count ?? 0,
      approvedCount: c?.approved_count ?? 0,
      rejectedCount: c?.rejected_count ?? 0,
      pendingHours: num(c?.pending_hours),
      approvedHours: num(c?.approved_hours),
      presentDays,
      absentDays,
      daily: daily.map((d) => ({ date: String(d.date).slice(0, 10), hours: num(d.hours) })),
    };
  });

export const workerSummary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: { month: string; departmentId?: string; supervisorUserId?: string } ) => input)
  .handler(async ({ context, data }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const { from, to } = monthBounds(data.month);
    const sql = await getSql();
    const params: unknown[] = [from, to];
    const where = ["p.role = 'worker'"];
    if (acting.role === "supervisor") {
      params.push(acting.userId);
      where.push(`p.supervisor_user_id = $${params.length}`);
    } else if (acting.role === "worker") {
      params.push(acting.userId);
      where.push(`p.user_id = $${params.length}`);
    }
    if (data.departmentId) {
      params.push(data.departmentId);
      where.push(`p.department_id = $${params.length}`);
    }
    if (data.supervisorUserId && isAdminRole(acting.role)) {
      params.push(data.supervisorUserId);
      where.push(`p.supervisor_user_id = $${params.length}`);
    }
    const rows = await sql.query<{
      user_id: string;
      full_name: string;
      employee_id: string | null;
      department_name: string | null;
      total_hours: unknown;
      approved_hours: unknown;
      pending_hours: unknown;
      rejected_hours: unknown;
      approved_count: unknown;
      pending_count: unknown;
      rejected_count: unknown;
      present_days: unknown;
      absent_days: unknown;
    }>(
      `select p.user_id, p.full_name, p.employee_id, d.name as department_name,
              coalesce(sum(o.total_hours) filter (where o.status <> 'rejected'), 0) as total_hours,
              coalesce(sum(o.total_hours) filter (where o.status = 'approved'), 0) as approved_hours,
              coalesce(sum(o.total_hours) filter (where o.status = 'pending'), 0) as pending_hours,
              coalesce(sum(o.total_hours) filter (where o.status = 'rejected'), 0) as rejected_hours,
              count(o.id) filter (where o.status = 'approved')::int as approved_count,
              count(o.id) filter (where o.status = 'pending')::int as pending_count,
              count(o.id) filter (where o.status = 'rejected')::int as rejected_count,
              (select count(*) from attendance a where a.worker_user_id = p.user_id and a.work_date between $1 and $2 and a.status = 'present')::int as present_days,
              (select count(*) from attendance a where a.worker_user_id = p.user_id and a.work_date between $1 and $2 and a.status = 'absent')::int as absent_days
       from profiles p
       left join departments d on d.id = p.department_id
       left join overtime_records o on o.worker_user_id = p.user_id and o.work_date between $1 and $2
       where ${where.join(" and ")}
       group by p.user_id, p.full_name, p.employee_id, d.name
       order by p.full_name`,
      params,
    );
    return rows.map(mapSummary);
  });

export const listAudit = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { acting } = await actorOf(context.userId);
    requireRole(acting, ["super_admin", "admin"]);
    const sql = await getSql();
    const rows = await sql.query<{
      id: string;
      actor_user_id: string | null;
      actor_name: string | null;
      actor_role: string | null;
      action: string;
      entity_type: string | null;
      entity_id: string | null;
      details: string | null;
      created_at: string;
    }>(`select * from audit_logs order by created_at desc limit 300`);
    return rows.map((r) => ({
      id: r.id,
      actorUserId: r.actor_user_id,
      actorName: r.actor_name,
      actorRole: r.actor_role,
      action: r.action,
      entityType: r.entity_type,
      entityId: r.entity_id,
      details: r.details,
      createdAt: String(r.created_at),
    }));
  });

export const getSettings = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { acting } = await actorOf(context.userId);
    requireActive(acting);
    const sql = await getSql();
    const rows = await sql.query<{ key: string; value: string }>(`select key, value from system_settings`);
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    return {
      companyName: map.company_name ?? APP_NAME,
      timezone: map.timezone ?? "Europe/Berlin",
      requireDescription: map.require_description === "true",
    };
  });

export const updateSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { companyName: string; timezone: string; requireDescription: boolean }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { acting } = await actorOf(context.userId);
      requireRole(acting, ["super_admin"]);
      const sql = await getSql();
      const entries: [string, string][] = [
        ["company_name", data.companyName.trim() || APP_NAME],
        ["timezone", data.timezone.trim() || "Europe/Berlin"],
        ["require_description", data.requireDescription ? "true" : "false"],
      ];
      for (const [k, v] of entries) {
        await sql.query(
          `insert into system_settings (key, value) values ($1,$2)
           on conflict (key) do update set value = excluded.value`,
          [k, v],
        );
      }
      await writeAudit({ actor: acting, action: "settings.updated", entityType: "settings", entityId: "system" });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

export const startImpersonation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((targetUserId: string) => targetUserId)
  .handler(async ({ context, data: targetUserId }) => {
    try {
      const actor = await actorOf(context.userId);
      requireRole(actor.real, ["super_admin"]);
      if (targetUserId === actor.real.userId) throw new AppError("You are already yourself.");
      const target = await loadProfile(targetUserId);
      if (!target) throw new AppError("User not found.", 404);
      const sql = await getSql();
      await sql.query(
        `insert into impersonation (actor_user_id, target_user_id, started_at)
         values ($1,$2,now())
         on conflict (actor_user_id) do update set target_user_id = excluded.target_user_id, started_at = now()`,
        [actor.real.userId, targetUserId],
      );
      await writeAudit({
        actor: actor.real,
        action: "impersonation.start",
        entityType: "profile",
        entityId: targetUserId,
        details: { as: target.fullName, role: target.role },
      });
      return { ok: true as const };
    } catch (err) {
      fail(err);
    }
  });

export const stopImpersonation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const real = await loadProfile(context.userId);
    await sql.query(`delete from impersonation where actor_user_id = $1`, [context.userId]);
    if (real) {
      await writeAudit({
        actor: real,
        action: "impersonation.end",
        entityType: "profile",
        entityId: context.userId,
      });
    }
    return { ok: true as const };
  });

export const exportExcel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      month?: string;
      from?: string;
      to?: string;
      departmentId?: string;
      supervisorUserId?: string;
      workerUserId?: string;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    try {
      const actor = await actorOf(context.userId);
      requireActive(actor.acting);
      if (!canExport(actor.acting.role)) {
        throw new AppError("Only Admins can export Excel reports.", 403);
      }
      const filters: OtFilters = {
        month: data.month,
        from: data.from,
        to: data.to,
        departmentId: data.departmentId,
        supervisorUserId: data.supervisorUserId,
        workerUserId: data.workerUserId,
      };
      const sql = await getSql();
      const params: unknown[] = [];
      const where = ["true"];
      const add = (fragment: string, value: unknown) => {
        params.push(value);
        where.push(fragment.replace("?", `$${params.length}`));
      };
      let periodLabel = "All dates";
      if (data.month) {
        const b = monthBounds(data.month);
        add("o.work_date >= ?", b.from);
        add("o.work_date <= ?", b.to);
        periodLabel = b.label;
      } else {
        if (data.from) add("o.work_date >= ?", data.from);
        if (data.to) add("o.work_date <= ?", data.to);
        if (data.from || data.to) periodLabel = `${data.from ?? "…"} to ${data.to ?? "…"}`;
      }
      if (data.departmentId) add("o.department_id = ?", data.departmentId);
      if (data.supervisorUserId) add("o.supervisor_user_id = ?", data.supervisorUserId);
      if (data.workerUserId) add("o.worker_user_id = ?", data.workerUserId);
      const rows = await sql.query(
        `${OT_SELECT} where ${where.join(" and ")} order by w.full_name, o.work_date, o.start_time`,
        params,
      );
      const records: OvertimeRecord[] = rows.map((row) => mapOvertime(row as Parameters<typeof mapOvertime>[0]));
      const summaryMap = new Map<string, ReturnType<typeof mapSummary>>();
      for (const rec of records) {
        const cur = summaryMap.get(rec.workerUserId) ?? {
          userId: rec.workerUserId,
          fullName: rec.workerName,
          employeeId: rec.employeeId,
          departmentName: rec.departmentName,
          totalHours: 0,
          approvedHours: 0,
          pendingHours: 0,
          rejectedHours: 0,
          approvedCount: 0,
          pendingCount: 0,
          rejectedCount: 0,
          presentDays: 0,
          absentDays: 0,
        };
        if (rec.status !== "rejected") cur.totalHours += rec.totalHours;
        if (rec.status === "approved") {
          cur.approvedHours += rec.totalHours;
          cur.approvedCount += 1;
        } else if (rec.status === "pending") {
          cur.pendingHours += rec.totalHours;
          cur.pendingCount += 1;
        } else {
          cur.rejectedHours += rec.totalHours;
          cur.rejectedCount += 1;
        }
        summaryMap.set(rec.workerUserId, cur);
      }
      const xml = buildOvertimeWorkbook({
        companyName: actor.companyName,
        title: "Overtime report",
        periodLabel,
        generatedAt: new Date().toISOString().replace("T", " ").slice(0, 19),
        generatedBy: actor.acting.fullName,
        records,
        summary: [...summaryMap.values()].sort((a, b) => a.fullName.localeCompare(b.fullName)),
      });
      await writeAudit({
        actor: actor.acting,
        action: "report.exported",
        entityType: "report",
        entityId: data.month ?? "custom",
        details: { records: records.length, periodLabel },
      });
      const filename = `overtime-${(data.month ?? "export").replaceAll("/", "-")}.xls`;
      return { filename, mime: "application/vnd.ms-excel", xml };
    } catch (err) {
      fail(err);
    }
  });

export const seedDemo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { acting } = await actorOf(context.userId);
    requireRole(acting, ["super_admin"]);
    await seedDemoCompany(acting);
    return { ok: true as const };
  });

export { canAddWorkers, canExport, canManageAdmins, canManageUsers };
