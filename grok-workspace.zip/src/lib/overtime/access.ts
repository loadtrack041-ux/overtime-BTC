import { getRequest } from "@tanstack/react-start/server";
import { getSql } from "@/lib/db";
import { APP_NAME } from "@/lib/brand";
import { hashPassword } from "better-auth/crypto";
import type {
  Actor,
  AttendanceRecord,
  AttendanceStatus,
  Department,
  OtStatus,
  OvertimeRecord,
  Profile,
  Role,
  WorkerSummary,
} from "./types";
import { isAdminRole } from "./types";
import { seedDemoCompany } from "./seed";

export class AppError extends Error {
  readonly status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.name = "AppError";
    this.status = status;
  }
}

export function newId(): string {
  return crypto.randomUUID();
}

export function newAccessToken(): string {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

export function num(value: unknown): number {
  if (typeof value === "number") return value;
  if (typeof value === "string") return Number(value);
  return 0;
}

export function assertTokenShape(token: string): string {
  const trimmed = token.trim();
  if (!trimmed || trimmed.length < 8 || trimmed.length > 96 || !/^[A-Za-z0-9_-]+$/.test(trimmed)) {
    throw new AppError("This worker link is invalid.", 404);
  }
  return trimmed;
}

type ProfileRow = {
  user_id: string;
  role: Role;
  full_name: string;
  employee_id: string | null;
  department_id: string | null;
  department_name: string | null;
  supervisor_user_id: string | null;
  supervisor_name: string | null;
  phone: string | null;
  is_active: boolean;
  email: string | null;
  created_at: string;
};

export function mapProfile(row: ProfileRow): Profile {
  return {
    userId: row.user_id,
    role: row.role,
    fullName: row.full_name,
    employeeId: row.employee_id,
    departmentId: row.department_id,
    departmentName: row.department_name,
    supervisorUserId: row.supervisor_user_id,
    supervisorName: row.supervisor_name,
    phone: row.phone,
    isActive: row.is_active,
    email: row.email,
    createdAt: String(row.created_at),
  };
}

const PROFILE_SELECT = `
  select
    p.user_id,
    p.role,
    p.full_name,
    p.employee_id,
    p.department_id,
    d.name as department_name,
    p.supervisor_user_id,
    s.full_name as supervisor_name,
    p.phone,
    p.is_active,
    u.email,
    p.created_at
  from profiles p
  left join departments d on d.id = p.department_id
  left join profiles s on s.user_id = p.supervisor_user_id
  left join "user" u on u.id = p.user_id
`;

export async function loadProfile(userId: string): Promise<Profile | null> {
  const sql = await getSql();
  const rows = await sql.query<ProfileRow>(`${PROFILE_SELECT} where p.user_id = $1`, [userId]);
  return rows[0] ? mapProfile(rows[0]) : null;
}

export async function loadAuthUser(userId: string): Promise<{ name: string; email: string | null }> {
  const sql = await getSql();
  const rows = await sql.query<{ name: string; email: string | null }>(
    `select name, email from "user" where id = $1`,
    [userId],
  );
  return rows[0] ?? { name: "User", email: null };
}

export async function getSetting(key: string, fallback = ""): Promise<string> {
  const sql = await getSql();
  const rows = await sql.query<{ value: string }>(`select value from system_settings where key = $1`, [key]);
  return rows[0]?.value ?? fallback;
}

export async function writeAudit(opts: {
  actor: Profile;
  action: string;
  entityType?: string;
  entityId?: string;
  details?: unknown;
}): Promise<void> {
  const sql = await getSql();
  await sql.query(
    `insert into audit_logs (id, actor_user_id, actor_name, actor_role, action, entity_type, entity_id, details)
     values ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [
      newId(),
      opts.actor.userId,
      opts.actor.fullName,
      opts.actor.role,
      opts.action,
      opts.entityType ?? null,
      opts.entityId ?? null,
      opts.details ? JSON.stringify(opts.details) : null,
    ],
  );
}

export async function resolveActor(realUserId: string): Promise<Actor> {
  const sql = await getSql();
  let real = await loadProfile(realUserId);

  if (!real) {
    const authUser = await loadAuthUser(realUserId);
    const existingSa = await sql.query<{ n: number }>(
      `select count(*)::int as n from profiles where role = 'super_admin'`,
    );
    const isFirst = (existingSa[0]?.n ?? 0) === 0;
    await sql.query(
      `insert into profiles (user_id, role, full_name, employee_id, is_active, created_by)
       values ($1,$2,$3,$4,$5,$1)`,
      [
        realUserId,
        isFirst ? "super_admin" : "supervisor",
        authUser.name || authUser.email || "New supervisor",
        isFirst ? "SA-0001" : null,
        isFirst,
      ],
    );
    real = await loadProfile(realUserId);
    if (!real) throw new AppError("Could not create profile.", 500);
    if (isFirst) {
      await writeAudit({
        actor: real,
        action: "user.bootstrap_super_admin",
        entityType: "profile",
        entityId: real.userId,
      });
      await seedDemoCompany(real);
    } else {
      await writeAudit({
        actor: real,
        action: "user.pending_activation",
        entityType: "profile",
        entityId: real.userId,
        details: { email: authUser.email, role: "supervisor" },
      });
    }
  }

  const companyName = await getSetting("company_name", APP_NAME);

  const imp = await sql.query<{ target_user_id: string }>(
    `select target_user_id from impersonation where actor_user_id = $1`,
    [realUserId],
  );
  if (imp[0] && real.role === "super_admin") {
    const target = await loadProfile(imp[0].target_user_id);
    if (target && target.userId !== real.userId) {
      return { real, acting: target, impersonating: true, companyName };
    }
    await sql.query(`delete from impersonation where actor_user_id = $1`, [realUserId]);
  }

  return { real, acting: real, impersonating: false, companyName };
}

export function requireActive(profile: Profile): void {
  if (!profile.isActive) {
    throw new AppError("This account is deactivated. Contact an administrator.", 403);
  }
}

export function requireRole(profile: Profile, roles: Role[]): void {
  requireActive(profile);
  if (!roles.includes(profile.role)) {
    throw new AppError("You do not have permission to do that.", 403);
  }
}

export function assertCanViewWorker(actor: Profile, worker: Profile): void {
  requireActive(actor);
  if (isAdminRole(actor.role)) return;
  if (actor.role === "supervisor" && worker.supervisorUserId === actor.userId) return;
  if (actor.role === "worker" && worker.userId === actor.userId) return;
  throw new AppError("You can only view workers assigned to you.", 403);
}

export function clientMeta(): { ip: string | null; userAgent: string | null } {
  try {
    const request = getRequest();
    if (!request) return { ip: null, userAgent: null };
    const forwarded = request.headers.get("x-forwarded-for");
    const ip = forwarded?.split(",")[0]?.trim() || request.headers.get("x-real-ip");
    return { ip: ip || null, userAgent: request.headers.get("user-agent") };
  } catch {
    return { ip: null, userAgent: null };
  }
}

export async function hashUserPassword(password: string): Promise<string> {
  if (password.length < 8) throw new AppError("Password must be at least 8 characters.");
  return hashPassword(password);
}

export async function createAuthUser(opts: {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
}): Promise<void> {
  const sql = await getSql();
  const now = new Date().toISOString();
  const existing = await sql.query<{ id: string }>(`select id from "user" where email = $1`, [
    opts.email.toLowerCase(),
  ]);
  if (existing[0]) throw new AppError("An account with that email already exists.");
  await sql.query(
    `insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
     values ($1,$2,$3,true,$4,$4)`,
    [opts.id, opts.name, opts.email.toLowerCase(), now],
  );
  await sql.query(
    `insert into "account" (id, "accountId", "providerId", "userId", password, "createdAt", "updatedAt")
     values ($1,$2,'credential',$3,$4,$5,$5)`,
    [newId(), opts.id, opts.id, opts.passwordHash, now],
  );
}

export async function nextEmployeeId(prefix: string): Promise<string> {
  const sql = await getSql();
  const rows = await sql.query<{ employee_id: string }>(
    `select employee_id from profiles where employee_id like $1 order by employee_id desc limit 20`,
    [`${prefix}-%`],
  );
  let max = 1000;
  for (const row of rows) {
    const n = Number(row.employee_id.split("-")[1]);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return `${prefix}-${max + 1}`;
}

export async function issueWorkerLink(workerUserId: string, preferredToken?: string): Promise<string> {
  const sql = await getSql();
  await sql.query(`update worker_links set revoked_at = now() where worker_user_id = $1 and revoked_at is null`, [
    workerUserId,
  ]);
  const token = preferredToken ?? newAccessToken();
  await sql.query(`insert into worker_links (token, worker_user_id) values ($1, $2)`, [token, workerUserId]);
  return token;
}

export async function loadActiveWorkerToken(workerUserId: string): Promise<string | null> {
  const sql = await getSql();
  const rows = await sql.query<{ token: string }>(
    `select token from worker_links where worker_user_id = $1 and revoked_at is null order by created_at desc limit 1`,
    [workerUserId],
  );
  return rows[0]?.token ?? null;
}

export async function loadWorkerByToken(token: string): Promise<{ worker: Profile; companyName: string }> {
  const safe = assertTokenShape(token);
  const sql = await getSql();
  const rows = await sql.query<{ worker_user_id: string }>(
    `select worker_user_id from worker_links where token = $1 and revoked_at is null`,
    [safe],
  );
  if (!rows[0]) throw new AppError("This worker link is invalid or has been replaced.", 404);
  const worker = await loadProfile(rows[0].worker_user_id);
  if (!worker || worker.role !== "worker") throw new AppError("Worker not found.", 404);
  if (!worker.isActive) {
    throw new AppError("This worker profile is deactivated. Contact your supervisor.", 403);
  }
  await sql.query(`update worker_links set last_used_at = now() where token = $1`, [safe]);
  const companyName = await getSetting("company_name", APP_NAME);
  return { worker, companyName };
}

type OtRow = {
  id: string;
  worker_user_id: string;
  worker_name: string;
  employee_id: string | null;
  work_date: string;
  start_time: string;
  end_time: string;
  total_hours: unknown;
  crosses_midnight: boolean;
  description: string | null;
  status: OtStatus;
  department_id: string | null;
  department_name: string | null;
  supervisor_user_id: string | null;
  supervisor_name: string | null;
  approved_by_user_id: string | null;
  approved_by_name: string | null;
  signature_data: string | null;
  approved_at: string | null;
  approval_ip: string | null;
  approval_user_agent: string | null;
  rejection_reason: string | null;
  rejected_at: string | null;
  rejected_by_name: string | null;
  created_at: string;
  updated_at: string;
};

export function mapOvertime(row: OtRow): OvertimeRecord {
  return {
    id: row.id,
    workerUserId: row.worker_user_id,
    workerName: row.worker_name,
    employeeId: row.employee_id,
    workDate: String(row.work_date).slice(0, 10),
    startTime: row.start_time,
    endTime: row.end_time,
    totalHours: num(row.total_hours),
    crossesMidnight: row.crosses_midnight,
    description: row.description,
    status: row.status,
    departmentId: row.department_id,
    departmentName: row.department_name,
    supervisorUserId: row.supervisor_user_id,
    supervisorName: row.supervisor_name,
    approvedByUserId: row.approved_by_user_id,
    approvedByName: row.approved_by_name,
    signatureData: row.signature_data,
    approvedAt: row.approved_at ? String(row.approved_at) : null,
    approvalIp: row.approval_ip,
    approvalUserAgent: row.approval_user_agent,
    rejectionReason: row.rejection_reason,
    rejectedAt: row.rejected_at ? String(row.rejected_at) : null,
    rejectedByName: row.rejected_by_name,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export const OT_SELECT = `
  select
    o.id,
    o.worker_user_id,
    w.full_name as worker_name,
    w.employee_id,
    o.work_date,
    o.start_time,
    o.end_time,
    o.total_hours,
    o.crosses_midnight,
    o.description,
    o.status,
    o.department_id,
    d.name as department_name,
    o.supervisor_user_id,
    sv.full_name as supervisor_name,
    o.approved_by_user_id,
    o.approved_by_name,
    o.signature_data,
    o.approved_at,
    o.approval_ip,
    o.approval_user_agent,
    o.rejection_reason,
    o.rejected_at,
    o.rejected_by_name,
    o.created_at,
    o.updated_at
  from overtime_records o
  join profiles w on w.user_id = o.worker_user_id
  left join departments d on d.id = o.department_id
  left join profiles sv on sv.user_id = o.supervisor_user_id
`;

type AttendanceRow = {
  id: string;
  worker_user_id: string;
  worker_name: string;
  employee_id: string | null;
  department_name: string | null;
  work_date: string;
  status: AttendanceStatus;
  clock_in: string | null;
  clock_out: string | null;
  hours: unknown;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export function mapAttendance(row: AttendanceRow): AttendanceRecord {
  return {
    id: row.id,
    workerUserId: row.worker_user_id,
    workerName: row.worker_name,
    employeeId: row.employee_id,
    departmentName: row.department_name,
    workDate: String(row.work_date).slice(0, 10),
    status: row.status,
    clockIn: row.clock_in,
    clockOut: row.clock_out,
    hours: row.hours == null ? null : num(row.hours),
    notes: row.notes,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export const ATTENDANCE_SELECT = `
  select
    a.id,
    a.worker_user_id,
    w.full_name as worker_name,
    w.employee_id,
    d.name as department_name,
    a.work_date,
    a.status,
    a.clock_in,
    a.clock_out,
    a.hours,
    a.notes,
    a.created_at,
    a.updated_at
  from attendance a
  join profiles w on w.user_id = a.worker_user_id
  left join departments d on d.id = w.department_id
`;

export function overtimeScopeSql(actor: Profile, alias = "o"): { sql: string; params: unknown[] } {
  if (actor.role === "worker") {
    return { sql: `${alias}.worker_user_id = $1`, params: [actor.userId] };
  }
  if (actor.role === "supervisor") {
    return {
      sql: `${alias}.worker_user_id in (select user_id from profiles where supervisor_user_id = $1)`,
      params: [actor.userId],
    };
  }
  return { sql: "true", params: [] };
}

export async function listDepartmentsRows(activeOnly = false): Promise<Department[]> {
  const sql = await getSql();
  const rows = await sql.query<Department & { is_active: boolean; code: string | null }>(
    `select id, name, code, is_active from departments ${activeOnly ? "where is_active = true" : ""} order by name`,
  );
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    code: r.code,
    isActive: r.is_active,
  }));
}

export function mapSummary(row: {
  user_id: string;
  full_name: string;
  employee_id: string | null;
  department_name: string | null;
  total_hours: unknown;
  approved_hours: unknown;
  pending_hours: unknown;
  rejected_hours: unknown;
  approved_count: unknown;
  pending_count: unknown;
  rejected_count: unknown;
  present_days?: unknown;
  absent_days?: unknown;
}): WorkerSummary {
  return {
    userId: row.user_id,
    fullName: row.full_name,
    employeeId: row.employee_id,
    departmentName: row.department_name,
    totalHours: num(row.total_hours),
    approvedHours: num(row.approved_hours),
    pendingHours: num(row.pending_hours),
    rejectedHours: num(row.rejected_hours),
    approvedCount: num(row.approved_count),
    pendingCount: num(row.pending_count),
    rejectedCount: num(row.rejected_count),
    presentDays: num(row.present_days),
    absentDays: num(row.absent_days),
  };
}
