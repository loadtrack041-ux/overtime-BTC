export const DEMO_PASSWORD = "Ledger2026!";
