import type { OvertimeRecord, WorkerSummary } from "./types";
import { formatHours } from "./hours";

function xml(value: string): string {
  const map: Record<string, string> = {
    "&": "&" + "amp;",
    "<": "&" + "lt;",
    ">": "&" + "gt;",
    '"': "&" + "quot;",
    "'": "&" + "apos;",
  };
  return value.replace(/[&<>"']/g, (ch) => map[ch] ?? ch);
}

function cell(value: string | number, style: string, type: "String" | "Number" = "String"): string {
  if (typeof value === "number") {
    return `<Cell ss:StyleID="${style}"><Data ss:Type="Number">${value}</Data></Cell>`;
  }
  return `<Cell ss:StyleID="${style}"><Data ss:Type="${type}">${xml(value)}</Data></Cell>`;
}

function empty(style = "Body"): string {
  return `<Cell ss:StyleID="${style}"/>`;
}

export function buildOvertimeWorkbook(opts: {
  companyName: string;
  title: string;
  periodLabel: string;
  generatedAt: string;
  generatedBy: string;
  records: OvertimeRecord[];
  summary: WorkerSummary[];
}): string {
  const { companyName, title, periodLabel, generatedAt, generatedBy, records, summary } = opts;
  const grand = summary.reduce((s, w) => s + w.totalHours, 0);

  const header = [
    "Worker Name",
    "Employee ID",
    "Department/Project",
    "Date",
    "OT Start Time",
    "OT End Time",
    "Total OT Hours",
    "Description",
    "Supervisor Name",
    "Approval Status",
    "Approval Date",
    "Approval Time",
  ];

  const detailRows = records
    .map((r) => {
      const approvedStamp = r.approvedAt ?? r.rejectedAt;
      const datePart = approvedStamp ? approvedStamp.slice(0, 10) : "";
      const timePart = approvedStamp ? approvedStamp.slice(11, 19) : "";
      const style = r.status === "approved" ? "Approved" : r.status === "rejected" ? "Rejected" : "Pending";
      return `<Row ss:AutoFitHeight="1">
        ${cell(r.workerName, "Body")}
        ${cell(r.employeeId ?? "", "Body")}
        ${cell(r.departmentName ?? "", "Body")}
        ${cell(r.workDate, "Body")}
        ${cell(r.startTime, "Body")}
        ${cell(r.endTime, "Body")}
        ${cell(r.totalHours, "Hours")}
        ${cell(r.description ?? "", "Body")}
        ${cell(r.supervisorName ?? "", "Body")}
        ${cell(r.status.charAt(0).toUpperCase() + r.status.slice(1), style)}
        ${cell(datePart, "Body")}
        ${cell(timePart, "Body")}
      </Row>`;
    })
    .join("\n");

  const summaryRows = summary
    .map(
      (w) => `<Row>
        ${cell(w.fullName, "Body")}
        ${cell(w.employeeId ?? "", "Body")}
        ${cell(w.departmentName ?? "", "Body")}
        ${cell(w.totalHours, "Hours")}
        ${cell(w.approvedHours, "Hours")}
        ${cell(w.pendingHours, "Hours")}
      </Row>`,
    )
    .join("\n");

  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
  <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
    <Title>${xml(title)}</Title>
    <Author>${xml(generatedBy)}</Author>
    <Company>${xml(companyName)}</Company>
    <Created>${xml(generatedAt)}</Created>
  </DocumentProperties>
  <Styles>
    <Style ss:ID="Default" ss:Name="Normal">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#1A1714"/>
      <Alignment ss:Vertical="Center"/>
    </Style>
    <Style ss:ID="Brand">
      <Font ss:FontName="Calibri" ss:Size="18" ss:Bold="1" ss:Color="#21564C"/>
    </Style>
    <Style ss:ID="Sub">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#6B645B"/>
    </Style>
    <Style ss:ID="Head">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Bold="1" ss:Color="#FBF8F1"/>
      <Interior ss:Color="#21564C" ss:Pattern="Solid"/>
      <Alignment ss:Vertical="Center" ss:WrapText="1"/>
    </Style>
    <Style ss:ID="Body">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#1A1714"/>
      <Borders>
        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E6DFD2"/>
      </Borders>
    </Style>
    <Style ss:ID="Hours">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#1A1714"/>
      <NumberFormat ss:Format="0.00"/>
      <Borders>
        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E6DFD2"/>
      </Borders>
    </Style>
    <Style ss:ID="Approved">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#215C45"/>
      <Interior ss:Color="#D7EEE3" ss:Pattern="Solid"/>
    </Style>
    <Style ss:ID="Pending">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#8A5A22"/>
      <Interior ss:Color="#F4E6D0" ss:Pattern="Solid"/>
    </Style>
    <Style ss:ID="Rejected">
      <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#8B2E2E"/>
      <Interior ss:Color="#F3D6D4" ss:Pattern="Solid"/>
    </Style>
    <Style ss:ID="Total">
      <Font ss:FontName="Calibri" ss:Size="12" ss:Bold="1" ss:Color="#21564C"/>
      <Interior ss:Color="#DCE8E4" ss:Pattern="Solid"/>
      <NumberFormat ss:Format="0.00"/>
    </Style>
    <Style ss:ID="TotalLabel">
      <Font ss:FontName="Calibri" ss:Size="12" ss:Bold="1" ss:Color="#21564C"/>
      <Interior ss:Color="#DCE8E4" ss:Pattern="Solid"/>
    </Style>
  </Styles>
  <Worksheet ss:Name="Overtime">
    <Table ss:DefaultRowHeight="20">
      <Column ss:Width="140"/>
      <Column ss:Width="90"/>
      <Column ss:Width="130"/>
      <Column ss:Width="90"/>
      <Column ss:Width="90"/>
      <Column ss:Width="90"/>
      <Column ss:Width="90"/>
      <Column ss:Width="180"/>
      <Column ss:Width="130"/>
      <Column ss:Width="90"/>
      <Column ss:Width="100"/>
      <Column ss:Width="90"/>
      <Row ss:Height="28">${cell(companyName, "Brand")}${empty("Brand")}${empty("Brand")}</Row>
      <Row>${cell(title, "Sub")}</Row>
      <Row>${cell(`Period: ${periodLabel}`, "Sub")}</Row>
      <Row>${cell(`Generated ${generatedAt} by ${generatedBy}`, "Sub")}</Row>
      <Row/>
      <Row ss:Height="28">${header.map((h) => cell(h, "Head")).join("")}</Row>
      ${detailRows || `<Row>${cell("No overtime records for this selection.", "Body")}</Row>`}
      <Row/>
      <Row>
        ${cell("Grand Total OT Hours", "TotalLabel")}
        ${empty("TotalLabel")}${empty("TotalLabel")}${empty("TotalLabel")}${empty("TotalLabel")}${empty("TotalLabel")}
        ${cell(grand, "Total")}
      </Row>
      <Row>${cell(formatHours(grand), "Sub")}</Row>
    </Table>
    <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
      <FreezePanes/>
      <FrozenNoSplit/>
      <SplitHorizontal>6</SplitHorizontal>
      <TopRowBottomPane>6</TopRowBottomPane>
    </WorksheetOptions>
  </Worksheet>
  <Worksheet ss:Name="Summary">
    <Table ss:DefaultRowHeight="20">
      <Column ss:Width="160"/>
      <Column ss:Width="90"/>
      <Column ss:Width="130"/>
      <Column ss:Width="110"/>
      <Column ss:Width="110"/>
      <Column ss:Width="110"/>
      <Row ss:Height="28">${cell("Worker monthly totals", "Brand")}</Row>
      <Row>${cell(periodLabel, "Sub")}</Row>
      <Row/>
      <Row ss:Height="28">
        ${cell("Worker Name", "Head")}
        ${cell("Employee ID", "Head")}
        ${cell("Department/Project", "Head")}
        ${cell("Monthly Total OT Hours", "Head")}
        ${cell("Approved Hours", "Head")}
        ${cell("Pending Hours", "Head")}
      </Row>
      ${summaryRows || `<Row>${cell("No workers in this selection.", "Body")}</Row>`}
      <Row/>
      <Row>
        ${cell("Grand Total OT Hours", "TotalLabel")}
        ${empty("TotalLabel")}${empty("TotalLabel")}
        ${cell(grand, "Total")}
        ${empty("Total")}${empty("Total")}
      </Row>
    </Table>
  </Worksheet>
</Workbook>`;
}
