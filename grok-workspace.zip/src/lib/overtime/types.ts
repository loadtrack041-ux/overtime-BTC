export type Role = "super_admin" | "admin" | "supervisor" | "worker";

export type OtStatus = "pending" | "approved" | "rejected";

export type AttendanceStatus = "present" | "absent";

export type Profile = {
  userId: string;
  role: Role;
  fullName: string;
  employeeId: string | null;
  departmentId: string | null;
  departmentName: string | null;
  supervisorUserId: string | null;
  supervisorName: string | null;
  phone: string | null;
  isActive: boolean;
  email: string | null;
  createdAt: string;
};

export type Actor = {
  real: Profile;
  acting: Profile;
  impersonating: boolean;
  companyName: string;
};

export type Department = {
  id: string;
  name: string;
  code: string | null;
  isActive: boolean;
};

export type OvertimeRecord = {
  id: string;
  workerUserId: string;
  workerName: string;
  employeeId: string | null;
  workDate: string;
  startTime: string;
  endTime: string;
  totalHours: number;
  crossesMidnight: boolean;
  description: string | null;
  status: OtStatus;
  departmentId: string | null;
  departmentName: string | null;
  supervisorUserId: string | null;
  supervisorName: string | null;
  approvedByUserId: string | null;
  approvedByName: string | null;
  signatureData: string | null;
  approvedAt: string | null;
  approvalIp: string | null;
  approvalUserAgent: string | null;
  rejectionReason: string | null;
  rejectedAt: string | null;
  rejectedByName: string | null;
  createdAt: string;
  updatedAt: string;
};

export type AttendanceRecord = {
  id: string;
  workerUserId: string;
  workerName: string;
  employeeId: string | null;
  departmentName: string | null;
  workDate: string;
  status: AttendanceStatus;
  clockIn: string | null;
  clockOut: string | null;
  hours: number | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
};

export type WorkerPortal = {
  token: string;
  companyName: string;
  worker: Profile;
};

export type DashboardStats = {
  month: string;
  totalWorkers: number;
  totalHours: number;
  pendingCount: number;
  approvedCount: number;
  rejectedCount: number;
  pendingHours: number;
  approvedHours: number;
  presentDays: number;
  absentDays: number;
  daily: { date: string; hours: number }[];
};

export type WorkerSummary = {
  userId: string;
  fullName: string;
  employeeId: string | null;
  departmentName: string | null;
  totalHours: number;
  approvedHours: number;
  pendingHours: number;
  rejectedHours: number;
  approvedCount: number;
  pendingCount: number;
  rejectedCount: number;
  presentDays: number;
  absentDays: number;
};

export type AuditEntry = {
  id: string;
  actorUserId: string | null;
  actorName: string | null;
  actorRole: string | null;
  action: string;
  entityType: string | null;
  entityId: string | null;
  details: string | null;
  createdAt: string;
};

export type OtFilters = {
  month?: string;
  from?: string;
  to?: string;
  workerUserId?: string;
  employeeId?: string;
  supervisorUserId?: string;
  departmentId?: string;
  status?: OtStatus | "";
};

export const ROLE_LABEL: Record<Role, string> = {
  super_admin: "Super Admin",
  admin: "Admin",
  supervisor: "Supervisor",
  worker: "Worker",
};

export const STATUS_LABEL: Record<OtStatus, string> = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
};

export function isAdminRole(role: Role): boolean {
  return role === "super_admin" || role === "admin";
}

export function canExport(role: Role): boolean {
  return isAdminRole(role);
}

export function canManageUsers(role: Role): boolean {
  return isAdminRole(role);
}

export function canManageAdmins(role: Role): boolean {
  return role === "super_admin";
}

export function canAddWorkers(role: Role): boolean {
  return isAdminRole(role) || role === "supervisor";
}

export function workerPortalPath(token: string): string {
  return `/w/${token}`;
}
