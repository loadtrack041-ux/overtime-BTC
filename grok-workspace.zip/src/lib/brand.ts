export const APP_NAME = "Overtime LEDGER (BTC)";
export const DEVELOPER_NAME = "Muddasir Ali";
